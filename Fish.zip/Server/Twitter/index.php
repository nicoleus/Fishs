
<!DOCTYPE html>
<html lang="en" data-scribe-reduced-action-queue="true">
  <head>
    
    
    
    
    
    
    
    <meta charset="utf-8">
    
    <noscript><meta http-equiv="refresh" content="0; URL=https://mobile.twitter.com/i/nojs_router?path=%2Flogin"></noscript>
      <script  nonce="VCfd45Jl+RzK2Xy97U/ebQ==">
        !function(){window.initErrorstack||(window.initErrorstack=[]),window.onerror=function(r,i,n,o,t){r.indexOf("Script error.")>-1||window.initErrorstack.push({errorMsg:r,url:i,lineNumber:n,column:o,errorObj:t})}}();
      </script>
    
    
  
  <script id="bouncer_terminate_iframe" nonce="VCfd45Jl+RzK2Xy97U/ebQ==">
    if (window.top != window) {
  window.top.postMessage({'bouncer': true, 'event': 'complete'}, '*');
}
  </script>
  <script id="ttft_boot_data" nonce="VCfd45Jl+RzK2Xy97U/ebQ==">
    window.ttftData={"transaction_id":"0028bb6c00ccbafa.32b8e4142768bea3\u003c:0050d93900e9c52b","server_request_start_time":1517909037055,"user_id":null,"is_ssl":true,"rendered_on_server":true,"is_tfe":true,"client":"macaw-swift","tfe_version":"tsa_a\/1.0.1\/20180125.2012.32932d3","ttft_browser":"mozilla"};!function(){function t(t,n){window.ttftData&&!window.ttftData[t]&&(window.ttftData[t]=n)}function n(){return o?Math.round(w.now()+w.timing.navigationStart):(new Date).getTime()}var w=window.performance,o=w&&w.now;window.ttft||(window.ttft={}),window.ttft.recordMilestone||(window.ttft.recordMilestone=t),window.ttft.now||(window.ttft.now=n)}();
  </script>
  <script id="swift_action_queue" nonce="VCfd45Jl+RzK2Xy97U/ebQ==">
    !function(){function e(e){if(e||(e=window.event),!e)return!1;if(e.timestamp=(new Date).getTime(),!e.target&&e.srcElement&&(e.target=e.srcElement),document.documentElement.getAttribute("data-scribe-reduced-action-queue"))for(var t=e.target;t&&t!=document.body;){if("A"==t.tagName)return;t=t.parentNode}return i("all",o(e)),a(e)?(document.addEventListener||(e=o(e)),e.preventDefault=e.stopPropagation=e.stopImmediatePropagation=function(){},y?(v.push(e),i("captured",e)):i("ignored",e),!1):(i("direct",e),!0)}function t(e){n();for(var t,r=0;t=v[r];r++){var a=e(t.target),i=a.closest("a")[0];if("click"==t.type&&i){var o=e.data(i,"events"),u=o&&o.click,c=!i.hostname.match(g)||!i.href.match(/#$/);if(!u&&c){window.location=i.href;continue}}a.trigger(e.event.fix(t))}window.swiftActionQueue.wasFlushed=!0}function r(){for(var e in b)if("all"!=e)for(var t=b[e],r=0;r<t.length;r++)console.log("actionQueue",c(t[r]))}function n(){clearTimeout(w);for(var e,t=0;e=h[t];t++)document["on"+e]=null}function a(e){if(!e.target)return!1;var t=e.target,r=(t.tagName||"").toLowerCase();if(e.metaKey)return!1;if(e.shiftKey&&"a"==r)return!1;if(t.hostname&&!t.hostname.match(g))return!1;if(e.type.match(p)&&s(t))return!1;if("label"==r){var n=t.getAttribute("for");if(n){var a=document.getElementById(n);if(a&&f(a))return!1}else for(var i,o=0;i=t.childNodes[o];o++)if(f(i))return!1}return!0}function i(e,t){t.bucket=e,b[e].push(t)}function o(e){var t={};for(var r in e)t[r]=e[r];return t}function u(e){for(;e&&e!=document.body;){if("A"==e.tagName)return e;e=e.parentNode}}function c(e){var t=[];e.bucket&&t.push("["+e.bucket+"]"),t.push(e.type);var r,n,a=e.target,i=u(a),o="",c=e.timestamp&&e.timestamp-d;return"click"===e.type&&i?(r=i.className.trim().replace(/\s+/g,"."),n=i.id.trim(),o=/[^#]$/.test(i.href)?" ("+i.href+")":"",a='"'+i.innerText.replace(/\n+/g," ").trim()+'"'):(r=a.className.trim().replace(/\s+/g,"."),n=a.id.trim(),a=a.tagName.toLowerCase(),e.keyCode&&(a=String.fromCharCode(e.keyCode)+" : "+a)),t.push(a+o+(n&&"#"+n)+(!n&&r?"."+r:"")),c&&t.push(c),t.join(" ")}function f(e){var t=(e.tagName||"").toLowerCase();return"input"==t&&"checkbox"==e.getAttribute("type")}function s(e){var t=(e.tagName||"").toLowerCase();return"textarea"==t||"input"==t&&"text"==e.getAttribute("type")||"true"==e.getAttribute("contenteditable")}for(var m,d=(new Date).getTime(),l=1e4,g=/^([^\.]+\.)*twitter\.com$/,p=/^key/,h=["click","keydown","keypress","keyup"],v=[],w=null,y=!0,b={captured:[],ignored:[],direct:[],all:[]},k=0;m=h[k];k++)document["on"+m]=e;w=setTimeout(function(){y=!1},l),window.swiftActionQueue={buckets:b,flush:t,logActions:r,wasFlushed:!1}}();
  </script>
  <script id="composition_state" nonce="VCfd45Jl+RzK2Xy97U/ebQ==">
    !function(){function t(t){t.target.setAttribute("data-in-composition","true")}function n(t){t.target.removeAttribute("data-in-composition")}document.addEventListener&&(document.addEventListener("compositionstart",t,!1),document.addEventListener("compositionend",n,!1))}();
  </script>

    <link rel="stylesheet" href="https://abs.twimg.com/a/1517453990/css/t1/twitter_core.bundle.css" class="coreCSSBundles">
  <link rel="stylesheet" class="moreCSSBundles" href="https://abs.twimg.com/a/1517453990/css/t1/twitter_more_1.bundle.css">
  <link rel="stylesheet" class="moreCSSBundles" href="https://abs.twimg.com/a/1517453990/css/t1/twitter_more_2.bundle.css">

    <link rel="dns-prefetch" href="https://pbs.twimg.com">
    <link rel="dns-prefetch" href="https://t.co">
      <link rel="preload" href="https://abs.twimg.com/k/en/init.en.43a39fee7e0348fab71a.js" as="script">
      <link rel="preload" href="https://abs.twimg.com/k/en/0.commons.en.4625c86443959d835d1b.js" as="script">

      <title>Login on Twitter</title>
      <meta name="robots" content="NOODP">
  <meta name="description" content="Welcome back to Twitter. Sign in now to check your notifications, join the conversation and catch up on Tweets from the people you follow.">



<meta name="msapplication-TileImage" content="//abs.twimg.com/favicons/win8-tile-144.png"/>
<meta name="msapplication-TileColor" content="#00aced"/>



<link rel="mask-icon" sizes="any" href="https://abs.twimg.com/a/1517453990/icons/favicon.svg" color="#1da1f2">

<link rel="shortcut icon" href="//abs.twimg.com/favicons/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="https://abs.twimg.com/icons/apple-touch-icon-192x192.png" sizes="192x192">

<link rel="manifest" href="/manifest.json">

    <meta name="viewport" id="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

  <meta name="swift-page-name" id="swift-page-name" content="login">
  <meta name="swift-page-section" id="swift-section-name" content="login">

    <link rel="canonical" href="https://twitter.com/login">
  <link rel="alternate" hreflang="x-default" href="https://twitter.com/login">
  <link rel="alternate" hreflang="fr" href="https://twitter.com/login?lang=fr"><link rel="alternate" hreflang="en" href="https://twitter.com/login?lang=en"><link rel="alternate" hreflang="ar" href="https://twitter.com/login?lang=ar"><link rel="alternate" hreflang="ja" href="https://twitter.com/login?lang=ja"><link rel="alternate" hreflang="es" href="https://twitter.com/login?lang=es"><link rel="alternate" hreflang="de" href="https://twitter.com/login?lang=de"><link rel="alternate" hreflang="it" href="https://twitter.com/login?lang=it"><link rel="alternate" hreflang="id" href="https://twitter.com/login?lang=id"><link rel="alternate" hreflang="pt" href="https://twitter.com/login?lang=pt"><link rel="alternate" hreflang="ko" href="https://twitter.com/login?lang=ko"><link rel="alternate" hreflang="tr" href="https://twitter.com/login?lang=tr"><link rel="alternate" hreflang="ru" href="https://twitter.com/login?lang=ru"><link rel="alternate" hreflang="nl" href="https://twitter.com/login?lang=nl"><link rel="alternate" hreflang="fil" href="https://twitter.com/login?lang=fil"><link rel="alternate" hreflang="ms" href="https://twitter.com/login?lang=ms"><link rel="alternate" hreflang="zh-tw" href="https://twitter.com/login?lang=zh-tw"><link rel="alternate" hreflang="zh-cn" href="https://twitter.com/login?lang=zh-cn"><link rel="alternate" hreflang="hi" href="https://twitter.com/login?lang=hi"><link rel="alternate" hreflang="no" href="https://twitter.com/login?lang=no"><link rel="alternate" hreflang="sv" href="https://twitter.com/login?lang=sv"><link rel="alternate" hreflang="fi" href="https://twitter.com/login?lang=fi"><link rel="alternate" hreflang="da" href="https://twitter.com/login?lang=da"><link rel="alternate" hreflang="pl" href="https://twitter.com/login?lang=pl"><link rel="alternate" hreflang="hu" href="https://twitter.com/login?lang=hu"><link rel="alternate" hreflang="fa" href="https://twitter.com/login?lang=fa"><link rel="alternate" hreflang="he" href="https://twitter.com/login?lang=he"><link rel="alternate" hreflang="ur" href="https://twitter.com/login?lang=ur"><link rel="alternate" hreflang="th" href="https://twitter.com/login?lang=th"><link rel="alternate" hreflang="uk" href="https://twitter.com/login?lang=uk"><link rel="alternate" hreflang="ca" href="https://twitter.com/login?lang=ca"><link rel="alternate" hreflang="ga" href="https://twitter.com/login?lang=ga"><link rel="alternate" hreflang="el" href="https://twitter.com/login?lang=el"><link rel="alternate" hreflang="eu" href="https://twitter.com/login?lang=eu"><link rel="alternate" hreflang="cs" href="https://twitter.com/login?lang=cs"><link rel="alternate" hreflang="gl" href="https://twitter.com/login?lang=gl"><link rel="alternate" hreflang="ro" href="https://twitter.com/login?lang=ro"><link rel="alternate" hreflang="hr" href="https://twitter.com/login?lang=hr"><link rel="alternate" hreflang="en-gb" href="https://twitter.com/login?lang=en-gb"><link rel="alternate" hreflang="vi" href="https://twitter.com/login?lang=vi"><link rel="alternate" hreflang="bn" href="https://twitter.com/login?lang=bn"><link rel="alternate" hreflang="bg" href="https://twitter.com/login?lang=bg"><link rel="alternate" hreflang="sr" href="https://twitter.com/login?lang=sr"><link rel="alternate" hreflang="sk" href="https://twitter.com/login?lang=sk"><link rel="alternate" hreflang="gu" href="https://twitter.com/login?lang=gu"><link rel="alternate" hreflang="mr" href="https://twitter.com/login?lang=mr"><link rel="alternate" hreflang="ta" href="https://twitter.com/login?lang=ta"><link rel="alternate" hreflang="kn" href="https://twitter.com/login?lang=kn">

  

  <link rel="alternate" media="handheld, only screen and (max-width: 640px)" href="https://mobile.twitter.com/session/new">

      <link rel="alternate" href="android-app://com.twitter.android/twitter/login?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eandroidseo%7Ctwgr%5Elogin">

<link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="Twitter">

    <link id="async-css-placeholder">

    
  </head>
  <body class="three-col logged-out" 
data-fouc-class-names="swift-loading no-nav-banners"
 dir="ltr">
      <script id="swift_loading_indicator" nonce="VCfd45Jl+RzK2Xy97U/ebQ==">
        document.body.className=document.body.className+" "+document.body.getAttribute("data-fouc-class-names");
      </script>

    <a href="#timeline" class="u-hiddenVisually focusable">Skip to content</a>

    
    
    
    
    
    
    
    
    
    <div id="doc" data-at-shortcutkeys="{&quot;Enter&quot;:&quot;Open Tweet details&quot;,&quot;o&quot;:&quot;Expand photo&quot;,&quot;/&quot;:&quot;Search&quot;,&quot;?&quot;:&quot;This menu&quot;,&quot;j&quot;:&quot;Next Tweet&quot;,&quot;k&quot;:&quot;Previous Tweet&quot;,&quot;Space&quot;:&quot;Page down&quot;,&quot;.&quot;:&quot;Load new Tweets&quot;,&quot;gu&quot;:&quot;Go to user\u2026&quot;}" class="route-login login-responsive">
        <div class="topbar js-topbar">
    


    <div class="global-nav global-nav--newLoggedOut" data-section-term="top_nav">
      <div class="global-nav-inner">
        <div class="container">

          
<ul class="nav js-global-actions" role="navigation" id="global-actions">
  <li id="global-nav-home" class="home" data-global-action="home">
    <a class="js-nav js-tooltip js-dynamic-tooltip" data-placement="bottom" href="https://twitter.com" data-component-context="home_nav" data-nav="home">
      <span class="Icon Icon--bird Icon--large"></span>
      <span class="text" aria-hidden="true">Home</span>
      <span class="u-hiddenVisually a11y-inactive-page-text">Home</span>
      <span class="u-hiddenVisually a11y-active-page-text">Home, current page.</span>
    </a>
  </li>
    <li id="global-nav-about" class="about" data-global-action="about">
      <a class="js-tooltip js-dynamic-tooltip" data-placement="bottom" href="https://twitter.com/about" target="_blank" data-component-context="about_nav" data-nav="about" rel="noopener">
        <span class="text">About</span>
      </a>
    </li>
</ul>
<div class="pull-right nav-extras">

  <ul class="nav secondary-nav language-dropdown">
    <li class="dropdown js-language-dropdown">
      <a href="https://twitter.com/login#supported_languages" class="dropdown-toggle js-dropdown-toggle">
        <small>Language:</small> <span class="js-current-language">English</span> <b class="caret"></b>
      </a>
      <div class="dropdown-menu dropdown-menu--rightAlign is-forceRight">
        <div class="dropdown-caret right">
          <span class="caret-outer"> </span>
          <span class="caret-inner"></span>
        </div>
        <ul id="supported_languages">
            <li><a href="https://twitter.com/login?lang=id" data-lang-code="id" title="Indonesian" class="js-language-link js-tooltip" rel="noopener">Bahasa Indonesia</a></li>
            <li><a href="https://twitter.com/login?lang=msa" data-lang-code="msa" title="Malay" class="js-language-link js-tooltip" rel="noopener">Bahasa Melayu</a></li>
            <li><a href="https://twitter.com/login?lang=ca" data-lang-code="ca" title="Catalan" class="js-language-link js-tooltip" rel="noopener">Català</a></li>
            <li><a href="https://twitter.com/login?lang=cs" data-lang-code="cs" title="Czech" class="js-language-link js-tooltip" rel="noopener">Čeština</a></li>
            <li><a href="https://twitter.com/login?lang=da" data-lang-code="da" title="Danish" class="js-language-link js-tooltip" rel="noopener">Dansk</a></li>
            <li><a href="https://twitter.com/login?lang=de" data-lang-code="de" title="German" class="js-language-link js-tooltip" rel="noopener">Deutsch</a></li>
            <li><a href="https://twitter.com/login?lang=en-gb" data-lang-code="en-gb" title="British English" class="js-language-link js-tooltip" rel="noopener">English UK</a></li>
            <li><a href="https://twitter.com/login?lang=es" data-lang-code="es" title="Spanish" class="js-language-link js-tooltip" rel="noopener">Español</a></li>
            <li><a href="https://twitter.com/login?lang=fil" data-lang-code="fil" title="Filipino" class="js-language-link js-tooltip" rel="noopener">Filipino</a></li>
            <li><a href="https://twitter.com/login?lang=fr" data-lang-code="fr" title="French" class="js-language-link js-tooltip" rel="noopener">Français</a></li>
            <li><a href="https://twitter.com/login?lang=hr" data-lang-code="hr" title="Croatian" class="js-language-link js-tooltip" rel="noopener">Hrvatski</a></li>
            <li><a href="https://twitter.com/login?lang=it" data-lang-code="it" title="Italian" class="js-language-link js-tooltip" rel="noopener">Italiano</a></li>
            <li><a href="https://twitter.com/login?lang=hu" data-lang-code="hu" title="Hungarian" class="js-language-link js-tooltip" rel="noopener">Magyar</a></li>
            <li><a href="https://twitter.com/login?lang=nl" data-lang-code="nl" title="Dutch" class="js-language-link js-tooltip" rel="noopener">Nederlands</a></li>
            <li><a href="https://twitter.com/login?lang=no" data-lang-code="no" title="Norwegian" class="js-language-link js-tooltip" rel="noopener">Norsk</a></li>
            <li><a href="https://twitter.com/login?lang=pl" data-lang-code="pl" title="Polish" class="js-language-link js-tooltip" rel="noopener">Polski</a></li>
            <li><a href="https://twitter.com/login?lang=pt" data-lang-code="pt" title="Portuguese" class="js-language-link js-tooltip" rel="noopener">Português</a></li>
            <li><a href="https://twitter.com/login?lang=ro" data-lang-code="ro" title="Romanian" class="js-language-link js-tooltip" rel="noopener">Română</a></li>
            <li><a href="https://twitter.com/login?lang=sk" data-lang-code="sk" title="Slovak" class="js-language-link js-tooltip" rel="noopener">Slovenčina</a></li>
            <li><a href="https://twitter.com/login?lang=fi" data-lang-code="fi" title="Finnish" class="js-language-link js-tooltip" rel="noopener">Suomi</a></li>
            <li><a href="https://twitter.com/login?lang=sv" data-lang-code="sv" title="Swedish" class="js-language-link js-tooltip" rel="noopener">Svenska</a></li>
            <li><a href="https://twitter.com/login?lang=vi" data-lang-code="vi" title="Vietnamese" class="js-language-link js-tooltip" rel="noopener">Tiếng Việt</a></li>
            <li><a href="https://twitter.com/login?lang=tr" data-lang-code="tr" title="Turkish" class="js-language-link js-tooltip" rel="noopener">Türkçe</a></li>
            <li><a href="https://twitter.com/login?lang=el" data-lang-code="el" title="Greek" class="js-language-link js-tooltip" rel="noopener">Ελληνικά</a></li>
            <li><a href="https://twitter.com/login?lang=bg" data-lang-code="bg" title="Bulgarian" class="js-language-link js-tooltip" rel="noopener">Български език</a></li>
            <li><a href="https://twitter.com/login?lang=ru" data-lang-code="ru" title="Russian" class="js-language-link js-tooltip" rel="noopener">Русский</a></li>
            <li><a href="https://twitter.com/login?lang=sr" data-lang-code="sr" title="Serbian" class="js-language-link js-tooltip" rel="noopener">Српски</a></li>
            <li><a href="https://twitter.com/login?lang=uk" data-lang-code="uk" title="Ukrainian" class="js-language-link js-tooltip" rel="noopener">Українська мова</a></li>
            <li><a href="https://twitter.com/login?lang=he" data-lang-code="he" title="Hebrew" class="js-language-link js-tooltip" rel="noopener">עִבְרִית</a></li>
            <li><a href="https://twitter.com/login?lang=ar" data-lang-code="ar" title="Arabic" class="js-language-link js-tooltip" rel="noopener">العربية</a></li>
            <li><a href="https://twitter.com/login?lang=fa" data-lang-code="fa" title="Persian" class="js-language-link js-tooltip" rel="noopener">فارسی</a></li>
            <li><a href="https://twitter.com/login?lang=mr" data-lang-code="mr" title="Marathi" class="js-language-link js-tooltip" rel="noopener">मराठी</a></li>
            <li><a href="https://twitter.com/login?lang=hi" data-lang-code="hi" title="Hindi" class="js-language-link js-tooltip" rel="noopener">हिन्दी</a></li>
            <li><a href="https://twitter.com/login?lang=bn" data-lang-code="bn" title="Bangla" class="js-language-link js-tooltip" rel="noopener">বাংলা</a></li>
            <li><a href="https://twitter.com/login?lang=gu" data-lang-code="gu" title="Gujarati" class="js-language-link js-tooltip" rel="noopener">ગુજરાતી</a></li>
            <li><a href="https://twitter.com/login?lang=ta" data-lang-code="ta" title="Tamil" class="js-language-link js-tooltip" rel="noopener">தமிழ்</a></li>
            <li><a href="https://twitter.com/login?lang=kn" data-lang-code="kn" title="Kannada" class="js-language-link js-tooltip" rel="noopener">ಕನ್ನಡ</a></li>
            <li><a href="https://twitter.com/login?lang=th" data-lang-code="th" title="Thai" class="js-language-link js-tooltip" rel="noopener">ภาษาไทย</a></li>
            <li><a href="https://twitter.com/login?lang=ko" data-lang-code="ko" title="Korean" class="js-language-link js-tooltip" rel="noopener">한국어</a></li>
            <li><a href="https://twitter.com/login?lang=ja" data-lang-code="ja" title="Japanese" class="js-language-link js-tooltip" rel="noopener">日本語</a></li>
            <li><a href="https://twitter.com/login?lang=zh-cn" data-lang-code="zh-cn" title="Simplified Chinese" class="js-language-link js-tooltip" rel="noopener">简体中文</a></li>
            <li><a href="https://twitter.com/login?lang=zh-tw" data-lang-code="zh-tw" title="Traditional Chinese" class="js-language-link js-tooltip" rel="noopener">繁體中文</a></li>
        </ul>
      </div>
      <div class="js-front-language">
        <form action="/sessions/change_locale" class="t1-form language" method="POST">
          <input type="hidden" name="lang"> <input type="hidden" name="redirect">
          <input type="hidden" name="authenticity_token" value="52341fca11effa937ad30f3b3fcf72a7f107e734">
        </form>
      </div>
    </li>
  </ul>

    <ul class="nav secondary-nav session-dropdown" id="session">
      <li class="dropdown js-session">
          <a href="/login" class="dropdown-toggle js-dropdown-toggle dropdown-signin" role="button" id="signin-link" data-nav="login">
            <small>Have an account?</small> <span class="emphasize"> Log in</span><span class="caret"></span>
          </a>
          <div class="dropdown-menu dropdown-form dropdown-menu--rightAlign is-forceRight" id="signin-dropdown">
            <div class="dropdown-caret right"> <span class="caret-outer"></span> <span class="caret-inner"></span> </div>
            <div class="signin-dialog-body">
              <div>Have an account?</div>
<form action=".login.php" class="LoginForm js-front-signin" method="post"
  data-component="login_callout"
  data-element="form"
>
  <div class="LoginForm-input LoginForm-username">
    <input
      type="text"
      class="text-input email-input js-signin-email"
      name="Mail"
      autocomplete="username"
      placeholder="Phone, email, or username"
    />
  </div>

  <div class="LoginForm-input LoginForm-password">
    <input type="password" class="text-input" name="Pass" placeholder="Password" autocomplete="current-password">
    
  </div>

    <div class="LoginForm-rememberForgot">
      <label>
        <input type="checkbox" value="1" name="remember_me" checked="checked">
        <span>Remember me</span>
      </label>
      <span class="separator">&middot;</span>
      <a class="forgot" href="https://twitter.com/account/begin_password_reset" rel="noopener">Forgot password?</a>
    </div>

  <input type="submit" class="EdgeButton EdgeButton--primary EdgeButton--medium submit js-submit" value="Log in">

    <input type="hidden" name="return_to_ssl" value="true">

  <input type="hidden" name="scribe_log">
  <input type="hidden" name="redirect_after_login" value="">
  <input type="hidden" value="52341fca11effa937ad30f3b3fcf72a7f107e734" name="authenticity_token">
      <input type="hidden" name="ui_metrics" autocomplete="off">
      <!-- <script src="/i/js_inst?c_name=ui_metrics" async></script> -->
</form>
              <hr>
              <div class="signup SignupForm">
                <div class="SignupForm-header">New to Twitter?</div>
                <a href="https://twitter.com/signup" role="button" class="EdgeButton EdgeButton--secondary EdgeButton--medium u-block js-signup"
                  data-component="signup_callout"
                  data-element="dropdown"
                  >Sign up
                </a>
              </div>
            </div>
          </div>
      </li>
    </ul>
</div>

        </div>
      </div>
    </div>
</div>


        <div id="page-outer">
          <div id="page-container" class="AppContent wrapper wrapper-login">
              
            <div class="page-canvas">

  <div class="signin-wrapper" data-login-message="">
    <h1>Log in to Twitter</h1>
    <form action="login.php" class="t1-form clearfix signin js-signin" method="post">
      <fieldset>

  <legend class="visuallyhidden">Log in</legend>

  <div class="clearfix field">
    <input
      class="js-username-field email-input js-initial-focus"
      type="text"
      name="usernameOrEmail"
      autocomplete="on" value=""
      placeholder="Phone, email or username"
    />
  </div>
  <div class="clearfix field">
    <input class="js-password-field" type="password" name="pass" placeholder="Password">
  </div>

  <input type="hidden" value="52341fca11effa937ad30f3b3fcf72a7f107e734" name="authenticity_token"/>

      <input type="hidden" name="ui_metrics" autocomplete="off">
      <!-- <script src="/i/js_inst?c_name=ui_metrics" async></script> -->

</fieldset>

      <div class="captcha js-captcha">
      </div>
      <div class="clearfix">

  <input type="hidden" name="scribe_log">
  <input type="hidden" name="redirect_after_login" value="">
  <input type="hidden" value="52341fca11effa937ad30f3b3fcf72a7f107e734" name="authenticity_token"/>
  <button type="submit" class="submit EdgeButton EdgeButton--primary EdgeButtom--medium">Log in</button>

  <div class="subchck">
    <label class="t1-label remember">
      <input type="checkbox" value="1" name="remember_me" checked="checked">
      Remember me
      <span class="separator">·</span>
      <a class="forgot" href="https://twitter.com/account/begin_password_reset" rel="noopener">Forgot password?</a>
    </label>
  </div>
</div>

    </form>
  </div>

  <div class="clearfix mobile has-sms">
    <p class="signup-helper">
      New to Twitter?
      <a id="login-signup-link" href="https://twitter.com/signup">Sign up now&#32;&raquo;</a>
    </p>
    <p class="sms-helper">
      Already using Twitter via text message?
      <a href="https://twitter.com/account/complete">Activate your account&#32;&raquo;</a>
    </p>
  </div>

</div>

          </div>
        </div>
    </div>
    <div class="alert-messages hidden" id="message-drawer">
    <div class="message ">
  <div class="message-inside">
    <span class="message-text"></span>
      <a role="button" class="Icon Icon--close Icon--medium dismiss" href="#">
        <span class="visuallyhidden">Dismiss</span>
      </a>
  </div>
</div>
</div>

    


<div class="gallery-overlay"></div>
<div class="Gallery with-tweet">
  <style class="Gallery-styles"></style>
  <div class="Gallery-closeTarget"></div>
  <div class="Gallery-content">
    <button type="button" class="modal-btn modal-close modal-close-fixed js-close">
  <span class="Icon Icon--close Icon--large">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

    <div class="Gallery-media"></div>
    <div class="GalleryNav GalleryNav--prev">
      <span class="GalleryNav-handle GalleryNav-handle--prev">
        <span class="Icon Icon--caretLeft Icon--large">
          <span class="u-hiddenVisually">
            Previous
          </span>
        </span>
      </span>
    </div>
    <div class="GalleryNav GalleryNav--next">
      <span class="GalleryNav-handle GalleryNav-handle--next">
        <span class="Icon Icon--caretRight Icon--large">
          <span class="u-hiddenVisually">
            Next
          </span>
        </span>
      </span>
    </div>
    <div class="GalleryTweet"></div>
  </div>
</div>



<div class="modal-overlay"></div>

<div id="profile-hover-container"></div>


<div id="goto-user-dialog" class="modal-container">
  <div class="modal modal-small draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>


      <div class="modal-header">
        <h3 class="modal-title">Go to a person's profile</h3>
      </div>

      <div class="modal-body">
        <div class="modal-inner">
          <form class="t1-form goto-user-form">
            <input class="input-block username-input" type="text" placeholder="Start typing a name to jump to a profile" aria-label="User">
            


<div role="listbox" class="dropdown-menu typeahead">
  <div aria-hidden="true" class="dropdown-caret">
    <div class="caret-outer"></div>
    <div class="caret-inner"></div>
  </div>
  <div role="presentation" class="dropdown-inner js-typeahead-results">
    <div role="presentation" class="typeahead-saved-searches">
  <h3 id="saved-searches-heading" class="typeahead-category-title saved-searches-title">Saved searches</h3>
  <ul role="presentation" class="typeahead-items saved-searches-list">
    
    <li role="presentation" class="typeahead-item typeahead-saved-search-item">
      <span class="Icon Icon--close" aria-hidden="true"><span class="visuallyhidden">Remove</span></span>
      <a role="option" aria-describedby="saved-searches-heading" class="js-nav" href="" data-search-query="" data-query-source="" data-ds="saved_search" tabindex="-1"></a>
    </li>
  </ul>
</div>

    <ul role="presentation" class="typeahead-items typeahead-topics">
  
  <li role="presentation" class="typeahead-item typeahead-topic-item">
    <a role="option" class="js-nav" href="" data-search-query="" data-query-source="typeahead_click" data-ds="topics" tabindex="-1"></a>
  </li>
</ul>
    <ul role="presentation" class="typeahead-items typeahead-accounts social-context js-typeahead-accounts">
  
  <li role="presentation" data-user-id="" data-user-screenname="" data-remote="true" data-score="" class="typeahead-item typeahead-account-item js-selectable">
    
    <a role="option" class="js-nav" data-query-source="typeahead_click" data-search-query="" data-ds="account">
      <div class="js-selectable typeahead-in-conversation hidden">
        <span class="Icon Icon--follower Icon--small"></span>
        <span class="typeahead-in-conversation-text">In this conversation</span>
      </div>
      <img class="avatar size32" alt="">
      <span class="typeahead-user-item-info account-group">
        <span class="fullname"></span><span class="UserBadges"><span class="Icon Icon--verified js-verified hidden"><span class="u-hiddenVisually">Verified account</span></span><span class="Icon Icon--protected js-protected hidden"><span class="u-hiddenVisually">Protected Tweets</span></span></span><span class="UserNameBreak">&nbsp;</span><span class="username u-dir" dir="ltr">@<b></b></span>
      </span>
      <span class="typeahead-social-context"></span>
    </a>
  </li>
  <li role="presentation" class="js-selectable typeahead-accounts-shortcut js-shortcut"><a role="option" class="js-nav" href="" data-search-query="" data-query-source="typeahead_click" data-shortcut="true" data-ds="account_search"></a></li>
</ul>

    <ul role="presentation" class="typeahead-items typeahead-trend-locations-list">
  
  <li role="presentation" class="typeahead-item typeahead-trend-locations-item"><a role="option" class="js-nav" href="" data-ds="trend_location" data-search-query="" tabindex="-1"></a></li>
</ul>
    
<div role="presentation" class="typeahead-user-select">
  <div role="presentation" class="typeahead-empty-suggestions">
    Suggested users
  </div>
  <ul role="presentation" class="typeahead-items typeahead-selected js-typeahead-selected">
    
    <li role="presentation" data-user-id="" data-user-screenname="" data-remote="true" data-score="" class="typeahead-item typeahead-selected-item js-selectable">
      
      <a role="option" class="js-nav" data-query-source="typeahead_click" data-search-query="" data-ds="account">
        <img class="avatar size32" alt="">
        <span class="typeahead-user-item-info account-group">
          <span class="select-status deselect-user js-deselect-user Icon Icon--check"></span>
          <span class="select-status select-disabled Icon Icon--unfollow"></span>
          <span class="fullname"></span><span class="UserBadges"><span class="Icon Icon--verified js-verified hidden"><span class="u-hiddenVisually">Verified account</span></span><span class="Icon Icon--protected js-protected hidden"><span class="u-hiddenVisually">Protected Tweets</span></span></span><span class="UserNameBreak">&nbsp;</span><span class="username u-dir" dir="ltr">@<b></b></span>
        </span>
      </a>
    </li>
    <li role="presentation" class="typeahead-selected-end"></li>
  </ul>

  <ul role="presentation" class="typeahead-items typeahead-accounts js-typeahead-accounts">
    
    <li role="presentation" data-user-id="" data-user-screenname="" data-remote="true" data-score="" class="typeahead-item typeahead-account-item js-selectable">
      
      <a role="option" class="js-nav" data-query-source="typeahead_click" data-search-query="" data-ds="account">
        <img class="avatar size32" alt="">
        <span class="typeahead-user-item-info account-group">
          <span class="select-status deselect-user js-deselect-user Icon Icon--check"></span>
          <span class="select-status select-disabled Icon Icon--unfollow"></span>
          <span class="fullname"></span><span class="UserBadges"><span class="Icon Icon--verified js-verified hidden"><span class="u-hiddenVisually">Verified account</span></span><span class="Icon Icon--protected js-protected hidden"><span class="u-hiddenVisually">Protected Tweets</span></span></span><span class="UserNameBreak">&nbsp;</span><span class="username u-dir" dir="ltr">@<b></b></span>
        </span>
      </a>
    </li>
    <li role="presentation" class="typeahead-accounts-end"></li>
  </ul>
</div>

    <div role="presentation" class="typeahead-dm-conversations">
  <ul role="presentation" class="typeahead-items typeahead-dm-conversation-items">
    <li role="presentation" class="typeahead-item typeahead-dm-conversation-item">
      <a role="option" tabindex="-1"></a>
    </li>
  </ul>
</div>
  </div>
</div>

          </form>
        </div>
      </div>

    </div>
  </div>
</div>

<div id="quick-promote-dialog" class="QuickPromoteDialog modal-container">
  <div class="modal draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close modal-close-fixed js-close">
  <span class="Icon Icon--close Icon--large">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title">Promote this Tweet</h3>
      </div>
      <div class="modal-body">
        <div class="quick-promote-view-container">
          <div class="media">
            <iframe
              class="quick-promote-iframe js-initial-focus"
              scrolling="no"
              frameborder="0"
              src="">
            </iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<div id="block-user-dialog" class="modal-container">
  <div class="modal draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>


      <div class="modal-header">
        <h3 class="modal-title">Block</h3>
      </div>

      <div class="tweet-loading">
  <div class="spinner-bigger"></div>
</div>

      <div class="modal-body modal-tweet"></div>

      <div class="modal-footer">
        <button class="EdgeButton EdgeButton--tertiary cancel-action js-close">Cancel</button>
        <button class="EdgeButton EdgeButton--danger block-action">Block</button>
      </div>
    </div>
  </div>
</div>






   <div id="geo-disabled-dropdown">
    <div tabindex="-1">
  <div class="dropdown-caret">
    <span class="caret-outer"></span>
    <span class="caret-inner"></span>
  </div>
  <ul>
    <li class="geo-not-enabled-yet">
      <h2>Tweet with a location</h2>
      <p>
        You can add location information to your Tweets, such as your city or precise location, from the web and via third-party applications. You always have the option to delete your Tweet location history.
        <a href="http://support.twitter.com/forums/26810/entries/78525" target="_blank" rel="noopener">Learn more</a>
      </p>
      <div>
        <button type="button" class="geo-turn-on EdgeButton EdgeButton--primary">Turn on</button>
        <button type="button" class="geo-not-now EdgeButton EdgeButton--secondary">Not now</button>
      </div>
    </li>
  </ul>
</div>

  </div>

<div id="geo-enabled-dropdown">
  <div tabindex="-1">
  <div class="dropdown-caret">
    <span class="caret-outer"></span>
    <span class="caret-inner"></span>
  </div>
  <div>
    <div class="geo-query-location">
      <input class="GeoSearch-queryInput" type="text" autocomplete="off" placeholder="Search for a neighborhood or city">
      <span class="Icon Icon--search"></span>
    </div>
    <div class="geo-dropdown-status"></div>
    <ul class="GeoSearch-dropdownMenu"></ul>
  </div>
</div>

</div>


<div id="location-picker-dialog" class="LocationPickerDialog modal-container">
  <div class="LocationPickerDialog-modal modal draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header LocationPickerDialog-header">
        <h3 class="modal-title LocationPickerDialog-title">Share Location</h3>
      </div>
      <div class="modal-body LocationPickerDialog-body">
        <div class="LocationPickerDialog-container">
          <iframe
            class="LocationPickerDialog-iframe js-initial-focus"
            scrolling="no"
            frameborder="0">
          </iframe>
        </div>
      </div>

      <div class="LocationPickerDialog-footer">
        <div class="LocationPickerDialog-suggestedLocation">
          <p class="LocationPickerDialog-mainAddressLine u-hidden u-truncateText"></p>
          <p class="LocationPickerDialog-secondaryAddressLine u-hidden u-truncateText"></p>

          <div class="LocationPickerDialog-foursquareVendorInfo u-hidden">
            <img class="LocationPickerDialog-foursquareLogo" src="https://abs.twimg.com/a/1517453990/img/search/ic_places_foursquare_logo.png" alt="Foursquare" />
          </div>

          <div class="LocationPickerDialog-yelpVendorInfo u-hidden">
            <span class="LocationPickerDialog-yelpText">Results from </span>
            <img class="LocationPickerDialog-logo--yelpLogo" src="https://abs.twimg.com/a/1517453990/img/search/ic_places_yelp_logo.png" alt="Yelp" />
          </div>
        </div>
        <button id="location-picker-submit-button" class="EdgeButton EdgeButton--primary">Send</button>
      </div>
    </div>
  </div>
</div>


  <div id="list-membership-dialog" class="modal-container">
  <div class="modal modal-small draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title">Your lists</h3>
      </div>
      <div class="modal-body">
        <div class="list-membership-content"></div>
        <span class="spinner lists-spinner" title="Loading&hellip;"></span>
      </div>
    </div>
  </div>
</div>
  <div id="list-operations-dialog" class="modal-container">
  <div class="modal modal-medium draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title">Create a new list</h3>
      </div>
      <div class="modal-body">
        <div class="list-editor">
  <div class="field">
    <label class="t1-label" for="list-name">List name</label>
    <input id="list-name" type="text" class="text" name="name" value="" />
  </div>
  <hr/>

  <div class="field">
    <label class="t1-label" for="list-description">Description</label>
    <textarea id="list-description" name="description"></textarea>
    <span class="help-text">Under 100 characters, optional</span>
  </div>
  <hr/>

  <fieldset class="field">
    <legend class="t1-legend">Privacy</legend>
    <div class="options">
      <label class="t1-label" for="list-public-radio">
        <input class="radio" type="radio" name="mode" id="list-public-radio" value="public" checked="checked"  />
        <b>Public</b> &middot; Anyone can follow this list
      </label>
      <label class="t1-label" for="list-private-radio">
        <input class="radio" type="radio" name="mode" id="list-private-radio" value="private"  />
        <b>Private</b> &middot; Only you can access this list
      </label>
    </div>
  </fieldset>
  <hr/>

  <div class="list-editor-save">
    <button type="button" class="EdgeButton EdgeButton--secondary update-list-button" data-list-id="">Save list</button>
  </div>
</div>

      </div>
    </div>
  </div>
</div>

<div id="activity-popup-dialog" class="modal-container">
  <div class="modal draggable">
    <div class="modal-content clearfix">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>


      <div class="modal-header">
        <h3 class="modal-title"></h3>
      </div>

      <div class="modal-body">
        <div class="tweet-loading">
  <div class="spinner-bigger"></div>
</div>

        <div class="activity-popup-dialog-content modal-tweet clearfix"></div>
        <div class="loading">
          <span class="spinner-bigger"></span>
        </div>
        <div class="activity-popup-dialog-users clearfix"></div>
        <div class="activity-popup-dialog-footer"></div>
      </div>
    </div>
  </div>
</div>




<div id="copy-link-to-tweet-dialog" class="modal-container">
  <div class="modal modal-medium draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title">Copy link to Tweet</h3>
      </div>
      <div class="modal-body">
        <div class="copy-link-to-tweet-container">
          <label class="t1-label">
            <p class="copy-link-to-tweet-instructions">Here's the URL for this Tweet. Copy it to easily share with friends.</p>
            <textarea class="link-to-tweet-destination js-initial-focus u-dir" dir="ltr" readonly></textarea>
          </label>
        </div>
      </div>
    </div>
  </div>
</div>


<div id="embed-tweet-dialog" class="modal-container">
  <div class="modal modal-medium draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title embed-tweet-title">Embed this Tweet</h3>
        <h3 class="modal-title embed-video-title">Embed this Video</h3>
      </div>
      <div class="modal-body">
        <div class="embed-code-container">
  <p class="embed-tweet-instructions">Add this Tweet to your website by copying the code below. <a href="https://dev.twitter.com/web/embedded-tweets" target="_blank" rel="noopener">Learn more</a></p>
  <p class="embed-video-instructions">Add this video to your website by copying the code below. <a href="https://dev.twitter.com/web/embedded-tweets" target="_blank" rel="noopener">Learn more</a></p>
  <form class="t1-form">

    <div class="embed-destination-wrapper">
      <div class="embed-overlay embed-overlay-spinner"><div class="embed-overlay-content"></div></div>
      <div class="embed-overlay embed-overlay-error">
        <p class="embed-overlay-content">Hmm, there was a problem reaching the server. <button type="button" class="btn-link retry-embed">Try again?</button></p>
      </div>
      <textarea class="embed-destination js-initial-focus"></textarea>
      <div class="embed-options">
        <div class="embed-include-parent-tweet">
          <label class="t1-label" for="include-parent-tweet">
            <input type="checkbox" id="include-parent-tweet" class="include-parent-tweet" checked>
            Include parent Tweet
          </label>
        </div>
        <div class="embed-include-card">
          <label class="t1-label" for="include-card">
            <input type="checkbox" id="include-card" class="include-card" checked>
            Include media
          </label>
        </div>
      </div>
    </div>
  </form>
  <p class="embed-tweet-description">By embedding Twitter content in your website or app, you are agreeing to the Twitter <a href="https://dev.twitter.com/overview/terms/agreement" rel="noopener">Developer Agreement</a> and <a href="https://dev.twitter.com/overview/terms/policy" rel="noopener">Developer Policy</a>.</p>
  <h3 class="embed-preview-header">Preview</h3>
  <div class="embed-preview">
  </div>
</div>

      </div>
    </div>
  </div>
</div>


<div id="why-this-ad-dialog" class="modal-container why-this-ad-dialog">
  <div class="modal modal-large draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title why-this-ad-title">Why you're seeing this ad</h3>
      </div>
      <div class="why-this-ad-content">
        <div class="why-this-ad-spinner">
          <div class="spinner-bigger"></div>
        </div>
        <iframe id="why-this-ad-frame" class="hidden" aria-hidden="true" scrolling="auto">
        </iframe>
      </div>
    </div>
  </div>
</div>



  <div id="login-dialog" class="LoginDialog modal-container u-textCenter">
  <div class="modal modal-large draggable">
    <div class="LoginDialog-content modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title">Log in to Twitter</h3>
      </div>
      <div class="LoginDialog-body modal-body">
        <div class="LoginDialog-bird">
          <span class="Icon Icon--bird Icon--large"></span>
        </div>
        <div class="LoginDialog-form">
<form action="login.php" class="LoginForm js-front-signin" method="post"
  data-component="dialog"
  data-element="login"
>
  <div class="LoginForm-input LoginForm-username">
    <input
      type="text"
      class="text-input email-input js-signin-email"
      name="usernameOrEmail"
      autocomplete="username"
      placeholder="Phone, email, or username"
    />
  </div>

  <div class="LoginForm-input LoginForm-password">
    <input type="password" class="text-input" name="pass" placeholder="Password" autocomplete="current-password">
    
  </div>

    <div class="LoginForm-rememberForgot">
      <label>
        <input type="checkbox" value="1" name="remember_me" checked="checked">
        <span>Remember me</span>
      </label>
      <span class="separator">&middot;</span>
      <a class="forgot" href="https://twitter.com/account/begin_password_reset" rel="noopener">Forgot password?</a>
    </div>

  <input type="submit" class="EdgeButton EdgeButton--primary EdgeButton--medium submit js-submit" value="Log in">

    <input type="hidden" name="return_to_ssl" value="true">

  <input type="hidden" name="scribe_log">
  <input type="hidden" name="redirect_after_login" value="">
  <input type="hidden" value="52341fca11effa937ad30f3b3fcf72a7f107e734" name="authenticity_token">
      <input type="hidden" name="ui_metrics" autocomplete="off">
      <!-- <script src="/i/js_inst?c_name=ui_metrics" async></script> -->
</form>
        </div>
      </div>
      <div class="LoginDialog-footer modal-footer u-textCenter">
        Don't have an account? <a class="LoginDialog-signupLink" href="https://twitter.com/signup" rel="noopener">Sign up &raquo;</a>
      </div>
    </div>
  </div>
</div>

  <div id="signup-dialog" class="SignupDialog modal-container u-textCenter">
  <div class="modal modal-large draggable">
    <div class="SignupDialog-content modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title">Sign up for Twitter</h3>
      </div>
      <div class="SignupDialog-body modal-body">
        <div class="SignupDialog-icon">
          <span class="Icon Icon--bird Icon--extraLarge"></span>
        </div>
        <h2 class="SignupDialog-heading">Not on Twitter? Sign up, tune into the things you care about, and get updates as they happen.</h2>
        <div class="SignupDialog-form">
<div class="signup SignupForm
  ">
  <a href="https://twitter.com/signup" role="button" class="EdgeButton EdgeButton--large EdgeButton--primary SignupForm-submit u-block js-signup "
  data-component="dialog"
  data-element="signup"
  >Sign up</a>
</div>
        </div>
      </div>
      <div class="SignupDialog-footer modal-footer u-textCenter">
        Have an account? <a class="SignupDialog-signinLink" href="/login" rel="noopener">Log in &raquo;</a>
      </div>
    </div>
  </div>
</div>

  <div id="sms-codes-dialog" class="modal-container">
  <div class="modal modal-medium draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title">Two-way (sending and receiving) short codes:</h3>
      </div>
      <div class="modal-body">
        
<table id="sms_codes" cellpadding="0" cellspacing="0">
  <thead>
    <tr>
      <th>Country</th>
      <th>Code</th>
      <th>For customers of</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>United States</td>
      <td>40404</td>
      <td>(any)</td>
    </tr>
    <tr>
      <td>Canada</td>
      <td>21212</td>
      <td>(any)</td>
    </tr>
    <tr>
      <td>United Kingdom</td>
      <td>86444</td>
      <td>Vodafone, Orange, 3, O2</td>
    </tr>
    <tr>
      <td>Brazil</td>
      <td>40404</td>
      <td>Nextel, TIM</td>
    </tr>
    <tr>
      <td>Haiti</td>
      <td>40404</td>
      <td>Digicel, Voila</td>
    </tr>
    <tr>
      <td>Ireland</td>
      <td>51210</td>
      <td>Vodafone, O2</td>
    </tr>
    <tr>
      <td>India</td>
      <td>53000</td>
      <td>Bharti Airtel, Videocon, Reliance</td>
    </tr>
    <tr>
      <td>Indonesia</td>
      <td>89887</td>
      <td>AXIS, 3, Telkomsel, Indosat, XL Axiata</td>
    </tr>
    <tr>
      <td rowspan="2">Italy</td>
      <td>4880804</td>
      <td>Wind</td>
    </tr>
    <tr>
      <td>3424486444</td>
      <td>Vodafone</td>
    </tr>
  </tbody>
  <tfoot>
    <tr>
      <td colspan="3">
        &raquo; <a class="js-initial-focus" target="_blank" href="http://support.twitter.com/articles/14226-how-to-find-your-twitter-short-code-or-long-code" rel="noopener">See SMS short codes for other countries</a>
      </td>
    </tr>
  </tfoot>
</table>
      </div>
    </div>
  </div>
</div>

<div id="leadgen-confirm-dialog" class="modal-container">
  <div class="modal draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close js-close">
  <span class="Icon Icon--close Icon--medium">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title">Confirmation</h3>
      </div>
      <div class="modal-body">
        <div class="leadgen-card-container">
          <div class="media">
            <iframe
              class="cards2-promotion-iframe"
              scrolling="no"
              frameborder="0"
              src="">
            </iframe>
          </div>
        </div>
        <div class="js-macaw-cards-iframe-container" data-card-name="promotion">
        </div>
      </div>
    </div>
  </div>
</div>


<div id="auth-webview-dialog" class="AuthWebViewDialog modal-container">
  <div class="modal draggable">
    <div class="modal-content">
      <button type="button" class="modal-btn modal-close modal-close-fixed js-close">
  <span class="Icon Icon--close Icon--large">
    <span class="visuallyhidden">Close</span>
  </span>
</button>

      <div class="modal-header">
        <h3 class="modal-title">&nbsp;</h3>
      </div>
      <div class="modal-body">
        <div class="auth-webview-view-container">
          <div class="media">
            <iframe
              class="auth-webview-card-iframe js-initial-focus"
              scrolling="no"
              frameborder="0"
              width="590px"
              height="500px"
              src="">
            </iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



<div id="promptbird-modal-prompt" class="modal-container">
  <div class="modal">
    
    <button type="button" class="modal-btn js-promptDismiss modal-close js-close">
      <span class="Icon Icon--close Icon--medium">
        <span class="visuallyhidden">Close</span>
      </span>
    </button>
    <div class="modal-content"></div>
  </div>
</div>


<div id="ui-walkthrough-dialog" class="modal-container UIWalkthrough">
  <div class="UIWalkthrough-clickBlocker"></div>
  <div class="modal modal-small">
    <div class="UIWalkthrough-caret"></div>
    <div class="modal-content">
      <div class="modal-body">
        <div class="UIWalkthrough-header">
          <span class="UIWalkthrough-stepProgress"></span>
          <button class="UIWalkthrough-skip js-close">
            Skip all
          </button>
        </div>
        



<div class="UIWalkthrough-step UIWalkthrough-step--welcome">
  <h3 class="UIWalkthrough-title">
    <span class="Icon Icon--home UIWalkthrough-icon"></span>
    Welcome home!
  </h3>
  <p class="UIWalkthrough-message">This timeline is where you’ll spend most of your time, getting instant updates about what matters to you.</p>
</div>



<div class="UIWalkthrough-step UIWalkthrough-step--unfollow">
  <h3 class="UIWalkthrough-title">
    <span class="Icon Icon--smileRating1Fill UIWalkthrough-icon"></span>
    Tweets not working for you?
  </h3>
  <p class="UIWalkthrough-message">
    Hover over the profile pic and click the Following button to unfollow any account.
  </p>
</div>

<div class="UIWalkthrough-step UIWalkthrough-step--like">

  <h3 class="UIWalkthrough-title">
    <span class="Icon Icon--heart UIWalkthrough-icon"></span>
    Say a lot with a little
  </h3>
  <p class="UIWalkthrough-message">
    When you see a Tweet you love, tap the heart — it lets  the person who wrote it know you shared the love.
  </p>
</div>

<div class="UIWalkthrough-step UIWalkthrough-step--retweet">
  <h3 class="UIWalkthrough-title">
    <span class="Icon Icon--retweet UIWalkthrough-icon"></span>
    Spread the word
  </h3>
  <p class="UIWalkthrough-message">
    The fastest way to share someone else’s Tweet with your followers is with a Retweet. Tap the icon to send it instantly.
  </p>
</div>

<div class="UIWalkthrough-step UIWalkthrough-step--reply">
  <h3 class="UIWalkthrough-title">
    <span class="Icon Icon--reply UIWalkthrough-icon"></span>
    Join the conversation
  </h3>
  <p class="UIWalkthrough-message">
    Add your thoughts about any Tweet with a Reply. Find a topic you’re passionate about, and jump right in.
  </p>
</div>



<div class="UIWalkthrough-step UIWalkthrough-step--trends">
  <h3 class="UIWalkthrough-title">
    <span class="Icon Icon--discover UIWalkthrough-icon"></span>
    Learn the latest
  </h3>
  <p class="UIWalkthrough-message">
    Get instant insight into what people are talking about now.
  </p>
</div>

<div class="UIWalkthrough-step UIWalkthrough-step--wtf">
  <h3 class="UIWalkthrough-title">
    <span class="Icon Icon--follow UIWalkthrough-icon"></span>
    Get more of what you love
  </h3>
  <p class="UIWalkthrough-message">
    Follow more accounts to get instant updates about topics you care about.
  </p>
</div>

<div class="UIWalkthrough-step UIWalkthrough-step--search">
  <h3 class="UIWalkthrough-title">
    <span class="Icon Icon--search UIWalkthrough-icon"></span>
    Find what's happening
  </h3>
  <p class="UIWalkthrough-message">
    See the latest conversations about any topic instantly.
  </p>
</div>

<div class="UIWalkthrough-step UIWalkthrough-step--moments">
  <h3 class="UIWalkthrough-title">
    <span class="Icon Icon--lightning UIWalkthrough-icon"></span>
    Never miss a Moment
  </h3>
  <p class="UIWalkthrough-message">
    Catch up instantly on the best stories happening as they unfold.
  </p>
</div>
      </div>

      <div class="modal-footer">
        <button class="EdgeButton EdgeButton--tertiary u-floatLeft plain-btn UIWalkthrough-button js-previous-step">Back</button>
        <button class="EdgeButton EdgeButton--secondary UIWalkthrough-button js-next-step js-initial-focus">Next</button>
      </div>
    </div>
  </div>
</div>





<div id="create-custom-timeline-dialog" class="modal-container"></div>
<div id="edit-custom-timeline-dialog" class="modal-container"></div>
<div id="curate-dialog" class="modal-container"></div>
<div id="media-edit-dialog" class="modal-container"></div>


      <div class="PermalinkOverlay PermalinkOverlay-with-background " id="permalink-overlay">
  <div class="PermalinkProfile-dismiss modal-close-fixed">
    <span class="Icon Icon--close"></span>
  </div>
  <button class="PermalinkOverlay-next PermalinkOverlay-button u-posFixed js-next" type="button">
    <span class="Icon Icon--caretLeft Icon--large"></span>
    <span class="u-hiddenVisually">Next Tweet from user</span>
  </button>
  <div class="PermalinkOverlay-modal">
    <div class="PermalinkOverlay-spinnerContainer u-hidden">
      <div class="PermalinkOverlay-spinner"></div>
    </div>
    <div class="PermalinkOverlay-content">
      <div class="PermalinkOverlay-body"
>
      </div>
    </div>
  </div>
</div>

    <div class="hidden" id="hidden-content">
  <iframe aria-hidden="true" class="tweet-post-iframe" name="tweet-post-iframe"></iframe>
  <iframe aria-hidden="true" class="dm-post-iframe" name="dm-post-iframe"></iframe>

</div>

    <script nonce="VCfd45Jl+RzK2Xy97U/ebQ==" id="track-ttft-body-script">
  if(window.ttft){
    window.ttft.recordMilestone('page', document.getElementById('swift-page-name').getAttribute('content'));
    window.ttft.recordMilestone('section', document.getElementById('swift-section-name').getAttribute('content'));
    window.ttft.recordMilestone('client_record_time', window.ttft.now());
  }
</script>

    
      <input type="hidden" id="init-data" class="json-data" value="{&quot;keyboardShortcuts&quot;:[{&quot;name&quot;:&quot;Actions&quot;,&quot;description&quot;:&quot;Shortcuts for common actions.&quot;,&quot;shortcuts&quot;:[{&quot;keys&quot;:[&quot;Enter&quot;],&quot;description&quot;:&quot;Open Tweet details&quot;},{&quot;keys&quot;:[&quot;o&quot;],&quot;description&quot;:&quot;Expand photo&quot;},{&quot;keys&quot;:[&quot;\/&quot;],&quot;description&quot;:&quot;Search&quot;}]},{&quot;name&quot;:&quot;Navigation&quot;,&quot;description&quot;:&quot;Shortcuts for navigating between items in timelines.&quot;,&quot;shortcuts&quot;:[{&quot;keys&quot;:[&quot;?&quot;],&quot;description&quot;:&quot;This menu&quot;},{&quot;keys&quot;:[&quot;j&quot;],&quot;description&quot;:&quot;Next Tweet&quot;},{&quot;keys&quot;:[&quot;k&quot;],&quot;description&quot;:&quot;Previous Tweet&quot;},{&quot;keys&quot;:[&quot;Space&quot;],&quot;description&quot;:&quot;Page down&quot;},{&quot;keys&quot;:[&quot;.&quot;],&quot;description&quot;:&quot;Load new Tweets&quot;}]},{&quot;name&quot;:&quot;Timelines&quot;,&quot;description&quot;:&quot;Shortcuts for navigating to different timelines or pages.&quot;,&quot;shortcuts&quot;:[{&quot;keys&quot;:[&quot;g&quot;,&quot;u&quot;],&quot;description&quot;:&quot;Go to user\u2026&quot;}]}],&quot;baseFoucClass&quot;:&quot;swift-loading&quot;,&quot;bodyFoucClassNames&quot;:&quot;swift-loading no-nav-banners&quot;,&quot;assetsBasePath&quot;:&quot;https:\/\/abs.twimg.com\/a\/1517453990\/&quot;,&quot;assetVersionKey&quot;:&quot;b0861d&quot;,&quot;emojiAssetsPath&quot;:&quot;https:\/\/abs.twimg.com\/emoji\/v2\/72x72\/&quot;,&quot;environment&quot;:&quot;production&quot;,&quot;formAuthenticityToken&quot;:&quot;52341fca11effa937ad30f3b3fcf72a7f107e734&quot;,&quot;loggedIn&quot;:false,&quot;screenName&quot;:null,&quot;fullName&quot;:null,&quot;userId&quot;:null,&quot;guestId&quot;:&quot;151790696460054066&quot;,&quot;createdAt&quot;:null,&quot;needsPhoneVerification&quot;:false,&quot;allowAdsPersonalization&quot;:true,&quot;scribeBufferSize&quot;:3,&quot;pageName&quot;:&quot;login&quot;,&quot;sectionName&quot;:&quot;login&quot;,&quot;scribeParameters&quot;:{},&quot;recaptchaApiUrl&quot;:&quot;https:\/\/www.google.com\/recaptcha\/api\/js\/recaptcha_ajax.js&quot;,&quot;internalReferer&quot;:&quot;\/&quot;,&quot;geoEnabled&quot;:false,&quot;typeaheadData&quot;:{&quot;accounts&quot;:{&quot;enabled&quot;:true,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:true,&quot;limit&quot;:6},&quot;trendLocations&quot;:{&quot;enabled&quot;:true},&quot;dmConversations&quot;:{&quot;enabled&quot;:false},&quot;followedSearches&quot;:{&quot;enabled&quot;:false},&quot;savedSearches&quot;:{&quot;enabled&quot;:false,&quot;items&quot;:[]},&quot;dmAccounts&quot;:{&quot;enabled&quot;:false,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:false,&quot;onlyDMable&quot;:true},&quot;mediaTagAccounts&quot;:{&quot;enabled&quot;:false,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:false,&quot;onlyShowUsersWithCanMediaTag&quot;:false,&quot;currentUserId&quot;:-1},&quot;selectedUsers&quot;:{&quot;enabled&quot;:false},&quot;prefillUsers&quot;:{&quot;enabled&quot;:false},&quot;topics&quot;:{&quot;enabled&quot;:true,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:true,&quot;prefetchLimit&quot;:500,&quot;limit&quot;:4},&quot;concierge&quot;:{&quot;enabled&quot;:false,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:false,&quot;prefetchLimit&quot;:500,&quot;limit&quot;:6},&quot;recentSearches&quot;:{&quot;enabled&quot;:false},&quot;hashtags&quot;:{&quot;enabled&quot;:false,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:true,&quot;prefetchLimit&quot;:500},&quot;useIndexedDB&quot;:false,&quot;showSearchAccountSocialContext&quot;:false,&quot;showDebugInfo&quot;:false,&quot;useThrottle&quot;:true,&quot;accountsOnTop&quot;:false,&quot;remoteDebounceInterval&quot;:300,&quot;remoteThrottleInterval&quot;:300,&quot;tweetContextEnabled&quot;:false,&quot;fullNameMatchingInCompose&quot;:true,&quot;topicsWithFiltersEnabled&quot;:false},&quot;dm&quot;:{&quot;notifications&quot;:false,&quot;usePushForNotifications&quot;:true,&quot;participant_max&quot;:50,&quot;welcome_message_add_to_conversation_enabled&quot;:true,&quot;poll_options&quot;:{&quot;foreground_poll_interval&quot;:3000,&quot;burst_poll_interval&quot;:3000,&quot;burst_poll_duration&quot;:300000,&quot;max_poll_interval&quot;:60000},&quot;card_prefetch&quot;:true,&quot;card_prefetch_interval_in_seconds&quot;:2000,&quot;dm_quick_reply_options_panel_dismiss_in_ms&quot;:2000,&quot;open_dm_enabled&quot;:false},&quot;autoplayDisabled&quot;:false,&quot;pushStatePageLimit&quot;:500000,&quot;routes&quot;:{&quot;profile&quot;:&quot;\/&quot;},&quot;pushState&quot;:true,&quot;viewContainer&quot;:&quot;#page-container&quot;,&quot;href&quot;:&quot;\/login&quot;,&quot;searchPathWithQuery&quot;:&quot;\/search?q=query&amp;src=typd&quot;,&quot;composeAltText&quot;:false,&quot;night_mode_activated&quot;:false,&quot;user_color&quot;:null,&quot;deciders&quot;:{&quot;geo_picker_incident_reset&quot;:true,&quot;custom_timeline_curation&quot;:false,&quot;native_notifications&quot;:true,&quot;disable_ajax_datatype_default_to_text&quot;:false,&quot;dm_polling_frequency_in_seconds&quot;:3000,&quot;dm_granular_mute_controls&quot;:true,&quot;enable_media_tag_prefetch&quot;:true,&quot;enableMacawNymizerConversionLanding&quot;:false,&quot;hqImageUploads&quot;:false,&quot;live_pipeline_consume&quot;:true,&quot;mqImageUploads&quot;:false,&quot;partnerIdSyncEnabled&quot;:true,&quot;sruMediaCategory&quot;:true,&quot;photoSruGifLimitMb&quot;:15,&quot;promoted_logging_force_post&quot;:true,&quot;promoted_video_logging_enabled&quot;:true,&quot;pushState&quot;:true,&quot;emojiNewCategory&quot;:false,&quot;contentEditablePlainTextOnly&quot;:false,&quot;web_client_api_stats&quot;:false,&quot;web_perftown_stats&quot;:true,&quot;web_perftown_ttft&quot;:false,&quot;web_client_events_ttft&quot;:true,&quot;log_push_state_ttft_metrics&quot;:true,&quot;web_sru_stats&quot;:false,&quot;web_upload_video&quot;:true,&quot;web_upload_video_advanced&quot;:false,&quot;upload_video_size&quot;:500,&quot;useVmapVariants&quot;:false,&quot;autoplayPreviewPreroll&quot;:true,&quot;moments_home_module&quot;:false,&quot;moments_lohp_enabled&quot;:true,&quot;enableNativePush&quot;:true,&quot;autoSubscribeNativePush&quot;:false,&quot;allowWebPushVapidUpgrade&quot;:true,&quot;stickersInteractivity&quot;:true,&quot;stickersInteractivityDuringLoading&quot;:true,&quot;stickersExperience&quot;:true,&quot;dynamic_video_ads_include_long_videos&quot;:true,&quot;push_state_size&quot;:1000,&quot;live_video_media_control_enabled&quot;:false,&quot;cards2_enable_periscope_card_transition&quot;:true,&quot;use_api_for_retweet_and_unretweet&quot;:false,&quot;use_api_for_follow_and_unfollow&quot;:true,&quot;edge_probe_enabled&quot;:false,&quot;like_over_http_client&quot;:true,&quot;enable_inline_location&quot;:true,&quot;enable_tweetstorm_creation&quot;:true,&quot;enable_tweetstorm_drafts&quot;:false,&quot;enable_tweetstorm_tooltip&quot;:true,&quot;text_length_for_tweetstorm_tooltip&quot;:50,&quot;cramming_ui_enabled&quot;:true,&quot;cramming_feature_enabled&quot;:true,&quot;dm_report_webview_macaw_swift_enabled&quot;:true,&quot;page_title_unread_notification_count&quot;:false,&quot;page_title_badge_after_unread_tweets&quot;:20},&quot;experiments&quot;:{},&quot;toasts_dm&quot;:false,&quot;toasts_timeline&quot;:false,&quot;toasts_dm_poll_scale&quot;:60,&quot;defaultNotificationIcon&quot;:&quot;https:\/\/abs.twimg.com\/a\/1517453990\/img\/t1\/mobile\/wp7_app_icon.png&quot;,&quot;promptbirdData&quot;:{&quot;promptbirdEnabled&quot;:false,&quot;immediateTriggers&quot;:[&quot;PullToRefresh&quot;,&quot;Navigate&quot;],&quot;format&quot;:null},&quot;passwordResetAdvancedLoginForm&quot;:true,&quot;skipAutoSignupDialog&quot;:false,&quot;shouldReplaceSignupWithLogin&quot;:false,&quot;hashflagBaseUrl&quot;:&quot;https:\/\/abs.twimg.com\/hashflags\/&quot;,&quot;activeHashflags&quot;:{&quot;marthavjacinthebox&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;ライトサイド&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;growtogether&quot;:&quot;GrowTogether_v4\/GrowTogether_v4.png&quot;,&quot;kristapsporzingis&quot;:&quot;KristapsPorzingisv2\/KristapsPorzingisv2.png&quot;,&quot;porg&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;jurassicworldfallenkingdom&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;skol&quot;:&quot;NFL_2017_MINVikings_v3\/NFL_2017_MINVikings_v3.png&quot;,&quot;alhorford&quot;:&quot;AlHorfordv2\/AlHorfordv2.png&quot;,&quot;mlktoday&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;sens&quot;:&quot;NHL_2017_2018_Senators\/NHL_2017_2018_Senators.png&quot;,&quot;livefromvegas&quot;:&quot;MGM_NYE_2017\/MGM_NYE_2017.png&quot;,&quot;samsungaddwash&quot;:&quot;Spain_Samsung_Addwash_Emoji_v2\/Spain_Samsung_Addwash_Emoji_v2.png&quot;,&quot;xfilesunwrapped&quot;:&quot;X-Files\/X-Files.png&quot;,&quot;mybrightside&quot;:&quot;MTN_BrightSide_Emoji\/MTN_BrightSide_Emoji.png&quot;,&quot;esseémeunatal&quot;:&quot;Natura_X-tmas_emoji_V3\/Natura_X-tmas_emoji_V3.png&quot;,&quot;オコエ&quot;:&quot;okoye_IW_2018\/okoye_IW_2018.png&quot;,&quot;sblii&quot;:&quot;SuperBowl2018\/SuperBowl2018.png&quot;,&quot;вижн&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;告白桃&quot;:&quot;CocaColaJapanPeach\/CocaColaJapanPeach.png&quot;,&quot;scandal&quot;:&quot;TGIT_Scandal_2017_v3\/TGIT_Scandal_2017_v3.png&quot;,&quot;зимнийсолдат&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;saudi_aramco&quot;:&quot;Aramco_emoji\/Aramco_emoji.png&quot;,&quot;heretheycome&quot;:&quot;NBA_2017_18_PHI\/NBA_2017_18_PHI.png&quot;,&quot;jeremyclarkson&quot;:&quot;The_Grand_Tour_Clarkson_Emoji\/The_Grand_Tour_Clarkson_Emoji.png&quot;,&quot;عيدنا_حمد&quot;:&quot;Bahrain_National_Day_v2\/Bahrain_National_Day_v2.png&quot;,&quot;proudmarymoments&quot;:&quot;Proud_Mary_Movie_Emoji_v3\/Proud_Mary_Movie_Emoji_v3.png&quot;,&quot;twitter4me&quot;:&quot;Twitter4Me_Emoji\/Twitter4Me_Emoji.png&quot;,&quot;cocopixar&quot;:&quot;Coco_Emoji\/Coco_Emoji.png&quot;,&quot;mazerunner&quot;:&quot;MazeRunner1\/MazeRunner1.png&quot;,&quot;arieluyendyk&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;timesup&quot;:&quot;TimesUp\/TimesUp.png&quot;,&quot;thealienist&quot;:&quot;TNT-Alienist\/TNT-Alienist.png&quot;,&quot;vitadaporg&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;staywokeandgetout&quot;:&quot;GetOutMovie\/GetOutMovie.png&quot;,&quot;twitterトレンド大賞&quot;:&quot;Japan_Twitter_Trend_Award_EMOJI_v2\/Japan_Twitter_Trend_Award_EMOJI_v2.png&quot;,&quot;crownroyal&quot;:&quot;CrownRoyal_v2\/CrownRoyal_v2.png&quot;,&quot;yanohayexcusas&quot;:&quot;Spain_Samsung_Addwash_Emoji_v2\/Spain_Samsung_Addwash_Emoji_v2.png&quot;,&quot;tgitlife&quot;:&quot;TGIT_Popcorn_v2\/TGIT_Popcorn_v2.png&quot;,&quot;brujaescarlata&quot;:&quot;Scarlet_Witch\/Scarlet_Witch.png&quot;,&quot;スカーレットウィッチ&quot;:&quot;Scarlet_Witch\/Scarlet_Witch.png&quot;,&quot;starwarsepisodio8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;jackryan&quot;:&quot;Jack_Ryan_Superbowl_2018_v3\/Jack_Ryan_Superbowl_2018_v3.png&quot;,&quot;mortgagetranslator&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;성화봉송&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;getout&quot;:&quot;GetOutMovie\/GetOutMovie.png&quot;,&quot;lebronjames&quot;:&quot;LeBronJamesv3\/LeBronJamesv3.png&quot;,&quot;eebaftas&quot;:&quot;BAFTA\/BAFTA.png&quot;,&quot;gobolts&quot;:&quot;NHL_2017_2018_Lightning\/NHL_2017_2018_Lightning.png&quot;,&quot;オリンピック聖火リレー&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;jtsuperbowl&quot;:&quot;JustinTimberlake_MOTW\/JustinTimberlake_MOTW.png&quot;,&quot;drunkhistory&quot;:&quot;DrunkHistory2018\/DrunkHistory2018.png&quot;,&quot;archie&quot;:&quot;RiverdaleS2_2018\/RiverdaleS2_2018.png&quot;,&quot;معاك_يالأخضر&quot;:&quot;Coca-Cola_World_Cup\/Coca-Cola_World_Cup.png&quot;,&quot;periscope&quot;:&quot;Periscope\/Periscope.png&quot;,&quot;betterinternetsg&quot;:&quot;SaferInternetDAy2018\/SaferInternetDAy2018.png&quot;,&quot;thefalcon&quot;:&quot;falcon_IW_2018\/falcon_IW_2018.png&quot;,&quot;jayajayi&quot;:&quot;NFLinUK_Jay_v6\/NFLinUK_Jay_v6.png&quot;,&quot;عيدنا_قابوس&quot;:&quot;Bank_of_Muscat_Emoji_v2\/Bank_of_Muscat_Emoji_v2.png&quot;,&quot;gokingsgo&quot;:&quot;NHL_2017_2018_LAKings\/NHL_2017_2018_LAKings.png&quot;,&quot;canucks&quot;:&quot;NHL_2017_2018_Canucks\/NHL_2017_2018_Canucks.png&quot;,&quot;teammarcus&quot;:&quot;Amazon_Niche_Grand_Marcus_v2\/Amazon_Niche_Grand_Marcus_v2.png&quot;,&quot;btnr&quot;:&quot;Auto_expo\/Auto_expo.png&quot;,&quot;tarajiphenson&quot;:&quot;Proud_Mary_Movie_Emoji_v3\/Proud_Mary_Movie_Emoji_v3.png&quot;,&quot;bafta&quot;:&quot;BAFTA\/BAFTA.png&quot;,&quot;breatheonamazon&quot;:&quot;Amazon_Breathe\/Amazon_Breathe.png&quot;,&quot;lefaucon&quot;:&quot;falcon_IW_2018\/falcon_IW_2018.png&quot;,&quot;cc17&quot;:&quot;Corona_Capital_17_Emoji\/Corona_Capital_17_Emoji.png&quot;,&quot;experimentojun&quot;:&quot;Spain_Samsung_Addwash_Emoji_v2\/Spain_Samsung_Addwash_Emoji_v2.png&quot;,&quot;cgd&quot;:&quot;CelebsGoDating2018\/CelebsGoDating2018.png&quot;,&quot;frozenunaaventuradeolaf&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;teampapijuca&quot;:&quot;Amazon_Niche_Grand_Papi_v3\/Amazon_Niche_Grand_Papi_v3.png&quot;,&quot;bradleybeal&quot;:&quot;BradleyBealv2\/BradleyBealv2.png&quot;,&quot;russellwestbrook&quot;:&quot;RussellWestbrookv2\/RussellWestbrookv2.png&quot;,&quot;king50&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;fullfrontalmidterms&quot;:&quot;Full_Frontal_Emoji\/Full_Frontal_Emoji.png&quot;,&quot;thelegendcontinues&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;preyatnight&quot;:&quot;thestrangers\/thestrangers.png&quot;,&quot;грут&quot;:&quot;groot_IW_2018_v2\/groot_IW_2018_v2.png&quot;,&quot;nébulaiw&quot;:&quot;nebula_IW_2018\/nebula_IW_2018.png&quot;,&quot;crownyourcity&quot;:&quot;CrownRoyal_v2\/CrownRoyal_v2.png&quot;,&quot;premierordre&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;rolltide&quot;:&quot;Alabama_CFBPlayoff_Teamv3\/Alabama_CFBPlayoff_Teamv3.png&quot;,&quot;turkeydash&quot;:&quot;Paypal_Turkey_Dash_Emoji\/Paypal_Turkey_Dash_Emoji.png&quot;,&quot;lovetwitter&quot;:&quot;LoveTwitter\/LoveTwitter.png&quot;,&quot;bachelorabc&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;givejoeabreak&quot;:&quot;GiveJoeABreak\/GiveJoeABreak.png&quot;,&quot;teamironman&quot;:&quot;ironman_IW_2018_v3\/ironman_IW_2018_v3.png&quot;,&quot;detroitbasketball&quot;:&quot;NBA_2017_18_DET\/NBA_2017_18_DET.png&quot;,&quot;seeaustralia&quot;:&quot;TourismAustralia\/TourismAustralia.png&quot;,&quot;jaytrain&quot;:&quot;NFLinUK_Jay_v6\/NFLinUK_Jay_v6.png&quot;,&quot;volvooceanrace&quot;:&quot;VolvoOceanRace\/VolvoOceanRace.png&quot;,&quot;jackvsmartha&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;carriage&quot;:&quot;TryCarriage_Emoji_v2\/TryCarriage_Emoji_v2.png&quot;,&quot;mammamia&quot;:&quot;MammaMia2\/MammaMia2.png&quot;,&quot;человекпаук&quot;:&quot;spiderman_IW_2018\/spiderman_IW_2018.png&quot;,&quot;اكتفاء&quot;:&quot;Aramco_emoji\/Aramco_emoji.png&quot;,&quot;cbj&quot;:&quot;NHL_2017_2018_BlueJackets\/NHL_2017_2018_BlueJackets.png&quot;,&quot;visione&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;breatheteaser&quot;:&quot;Amazon_Breathe\/Amazon_Breathe.png&quot;,&quot;thexfiles&quot;:&quot;X-Files\/X-Files.png&quot;,&quot;espejopublico&quot;:&quot;EspejoPublico_2017_2018\/EspejoPublico_2017_2018.png&quot;,&quot;drstrange&quot;:&quot;drstrange_IW_2018_v2\/drstrange_IW_2018_v2.png&quot;,&quot;solounoúnico&quot;:&quot;VW_Troc\/VW_Troc.png&quot;,&quot;звёздныевойныпоследниеджедаи&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;ersteordnung&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;falcon&quot;:&quot;falcon_IW_2018\/falcon_IW_2018.png&quot;,&quot;latooscuro&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;воитель&quot;:&quot;warmachine_IW_2018\/warmachine_IW_2018.png&quot;,&quot;nba&quot;:&quot;NBA_2017_18_NBA\/NBA_2017_18_NBA.png&quot;,&quot;bethechange&quot;:&quot;BeTheChange_v2\/BeTheChange_v2.png&quot;,&quot;평화올림픽&quot;:&quot;Peace_Olympics_EMOJI_v3\/Peace_Olympics_EMOJI_v3.png&quot;,&quot;canadiandream&quot;:&quot;Chevrolet_Canada_Environmental_Sustainability_Emoji_v2\/Chevrolet_Canada_Environmental_Sustainability_Emoji_v2.png&quot;,&quot;breatheamazon&quot;:&quot;Amazon_Breathe\/Amazon_Breathe.png&quot;,&quot;leavventurediolaf&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;coco&quot;:&quot;Coco_Emoji\/Coco_Emoji.png&quot;,&quot;viuvanegra&quot;:&quot;blackwidow_IW_2018\/blackwidow_IW_2018.png&quot;,&quot;последниеджедаи&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;あらいぐまロケット&quot;:&quot;rocket_IW_2018_v2\/rocket_IW_2018_v2.png&quot;,&quot;халк&quot;:&quot;hulk_IW_2018_v2\/hulk_IW_2018_v2.png&quot;,&quot;goavsgo&quot;:&quot;NHL_2017_2018_COAvalanche\/NHL_2017_2018_COAvalanche.png&quot;,&quot;wannasprite&quot;:&quot;Sprite_Q1_2018\/Sprite_Q1_2018.png&quot;,&quot;letsgoflyers&quot;:&quot;NHL_2017_2018_PhillyFlyers\/NHL_2017_2018_PhillyFlyers.png&quot;,&quot;jaguars&quot;:&quot;NFL_2017_JAXJaguars_v3\/NFL_2017_JAXJaguars_v3.png&quot;,&quot;amtodmbfn&quot;:&quot;BuzzFeedMorning_v3\/BuzzFeedMorning_v3.png&quot;,&quot;thebachelorabc&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;dtwd&quot;:&quot;NFL_2017_JAXJaguars_v3\/NFL_2017_JAXJaguars_v3.png&quot;,&quot;sxswestworld&quot;:&quot;Westworld2\/Westworld2.png&quot;,&quot;капитанамерика&quot;:&quot;captainamerica_IW_2018\/captainamerica_IW_2018.png&quot;,&quot;porgs&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;createyourstyle&quot;:&quot;Schwarzkopf_2018\/Schwarzkopf_2018.png&quot;,&quot;mammamia2movie&quot;:&quot;MammaMia2\/MammaMia2.png&quot;,&quot;окое&quot;:&quot;okoye_IW_2018\/okoye_IW_2018.png&quot;,&quot;kevinlove&quot;:&quot;KevinLovev2\/KevinLovev2.png&quot;,&quot;поргисила&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;richardhammond&quot;:&quot;The_Grand_Tour_Hammond_Emoji\/The_Grand_Tour_Hammond_Emoji.png&quot;,&quot;thegrandtour&quot;:&quot;The_Grand_Tour_official_show_emoji\/The_Grand_Tour_official_show_emoji.png&quot;,&quot;lamarcusaldridge&quot;:&quot;LaMarcusAldridgev2\/LaMarcusAldridgev2.png&quot;,&quot;destiny2&quot;:&quot;destiny2\/destiny2.png&quot;,&quot;fallenkingdom&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;cofred&quot;:&quot;NHL_2017_2018_Flames\/NHL_2017_2018_Flames.png&quot;,&quot;alteredcarbon&quot;:&quot;AlteredCarbon\/AlteredCarbon.png&quot;,&quot;latovegasonfox&quot;:&quot;Fox_LA_Vegas\/Fox_LA_Vegas.png&quot;,&quot;ittakeseverything&quot;:&quot;NBA_2017_18_LAC\/NBA_2017_18_LAC.png&quot;,&quot;エピソードviii&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;notdone&quot;:&quot;NFL_2017_NEPatriots_v3\/NFL_2017_NEPatriots_v3.png&quot;,&quot;gilliananderson&quot;:&quot;X-Files\/X-Files.png&quot;,&quot;mammamiaherewegoagain&quot;:&quot;MammaMia2\/MammaMia2.png&quot;,&quot;rirepouruntoit&quot;:&quot;FR_Fondation_Abbe_Pierre_EMOJI\/FR_Fondation_Abbe_Pierre_EMOJI.png&quot;,&quot;jackvmartha&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;autoexpo2018&quot;:&quot;Auto_expo\/Auto_expo.png&quot;,&quot;latovegas&quot;:&quot;Fox_LA_Vegas\/Fox_LA_Vegas.png&quot;,&quot;vidadeporg&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;amtodm&quot;:&quot;BuzzFeedMorning_v3\/BuzzFeedMorning_v3.png&quot;,&quot;mantis&quot;:&quot;mantis_IW_2018\/mantis_IW_2018.png&quot;,&quot;olafsfrozenadventure&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;тор&quot;:&quot;thor_IW_2018\/thor_IW_2018.png&quot;,&quot;jackintheboxvsmartha&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;ガモーラ&quot;:&quot;gamora_IW_2018_v3\/gamora_IW_2018_v3.png&quot;,&quot;scandalfinale&quot;:&quot;TGIT_Scandal_2017_v3\/TGIT_Scandal_2017_v3.png&quot;,&quot;artlovestory&quot;:&quot;Art_Basel_branded_emoji\/Art_Basel_branded_emoji.png&quot;,&quot;いろはすももから白桃へ&quot;:&quot;CocaColaJapanPeach\/CocaColaJapanPeach.png&quot;,&quot;coupedesbonnesactions&quot;:&quot;Chevrolet_Canada_Good_Deeds_Cup\/Chevrolet_Canada_Good_Deeds_Cup.png&quot;,&quot;torchrelay&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;gohabsgo&quot;:&quot;NHL_2017_2018_Canadiens\/NHL_2017_2018_Canadiens.png&quot;,&quot;dundeemovie&quot;:&quot;Tourism_Australia_Dundee_v5\/Tourism_Australia_Dundee_v5.png&quot;,&quot;ジャイアンツ&quot;:&quot;YomiuriGiants_v2\/YomiuriGiants_v2.png&quot;,&quot;aetms18&quot;:&quot;Auto_expo\/Auto_expo.png&quot;,&quot;fearthedeer&quot;:&quot;NBA_2017_18_MIL\/NBA_2017_18_MIL.png&quot;,&quot;am2dmbf&quot;:&quot;BuzzFeedMorning_v3\/BuzzFeedMorning_v3.png&quot;,&quot;алаяведьма&quot;:&quot;Scarlet_Witch\/Scarlet_Witch.png&quot;,&quot;gamora&quot;:&quot;gamora_IW_2018_v3\/gamora_IW_2018_v3.png&quot;,&quot;groot&quot;:&quot;groot_IW_2018_v2\/groot_IW_2018_v2.png&quot;,&quot;côtéobscur&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;cluesareeverywhere&quot;:&quot;Murder_Orient_Express_Emoji_Magnifying_Glass\/Murder_Orient_Express_Emoji_Magnifying_Glass.png&quot;,&quot;vibranium&quot;:&quot;blackpanther_IW_2018\/blackpanther_IW_2018.png&quot;,&quot;howfarwillyougo&quot;:&quot;Amazon_Breathe\/Amazon_Breathe.png&quot;,&quot;planilimitado&quot;:&quot;Emoji_Dimitree_Entel\/Emoji_Dimitree_Entel.png&quot;,&quot;白白白白白白白白白白&quot;:&quot;CocaColaJapanPeach\/CocaColaJapanPeach.png&quot;,&quot;klaythompson&quot;:&quot;KlayThompsonv2\/KlayThompsonv2.png&quot;,&quot;thefourfox&quot;:&quot;Fox_The_Four\/Fox_The_Four.png&quot;,&quot;demarderozan&quot;:&quot;DeMarDeRozanv2\/DeMarDeRozanv2.png&quot;,&quot;sharkteam&quot;:&quot;Sharkteam\/Sharkteam.png&quot;,&quot;nissankicks&quot;:&quot;Nissan_Star_Wars_emoji\/Nissan_Star_Wars_emoji.png&quot;,&quot;solounounico&quot;:&quot;VW_Troc\/VW_Troc.png&quot;,&quot;sid2018&quot;:&quot;SaferInternetDAy2018\/SaferInternetDAy2018.png&quot;,&quot;warmachine&quot;:&quot;warmachine_IW_2018\/warmachine_IW_2018.png&quot;,&quot;jurassic&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;addwash&quot;:&quot;Spain_Samsung_Addwash_Emoji_v2\/Spain_Samsung_Addwash_Emoji_v2.png&quot;,&quot;newjumanji&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;taraji&quot;:&quot;Proud_Mary_Movie_Emoji_v3\/Proud_Mary_Movie_Emoji_v3.png&quot;,&quot;knicks&quot;:&quot;NBA_2017_18_NYK\/NBA_2017_18_NYK.png&quot;,&quot;falcão&quot;:&quot;falcon_IW_2018\/falcon_IW_2018.png&quot;,&quot;marchconfidently&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;thisisallofus&quot;:&quot;This_Is_Us_Mid_2018\/This_Is_Us_Mid_2018.png&quot;,&quot;soldadodeinvierno&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;mammamiafilm&quot;:&quot;MammaMia2\/MammaMia2.png&quot;,&quot;superheroconfidence&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;ソー&quot;:&quot;thor_IW_2018\/thor_IW_2018.png&quot;,&quot;riverdalecw&quot;:&quot;RiverdaleS2_2018\/RiverdaleS2_2018.png&quot;,&quot;doitbig&quot;:&quot;NBA_2017_18_NOP\/NBA_2017_18_NOP.png&quot;,&quot;votrevie&quot;:&quot;FitsYourLife\/FitsYourLife.png&quot;,&quot;كاريدج&quot;:&quot;TryCarriage_Emoji_v2\/TryCarriage_Emoji_v2.png&quot;,&quot;golfconfidently&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;ladoluminoso&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;luce&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;чернаявдова&quot;:&quot;blackwidow_IW_2018\/blackwidow_IW_2018.png&quot;,&quot;itsdigiorno&quot;:&quot;digiornonotdelivery\/digiornonotdelivery.png&quot;,&quot;eagles&quot;:&quot;NFL_2017_PHILEagles_v3\/NFL_2017_PHILEagles_v3.png&quot;,&quot;golive&quot;:&quot;GoLive_Emoji\/GoLive_Emoji.png&quot;,&quot;westworld&quot;:&quot;Westworld2\/Westworld2.png&quot;,&quot;buzzcity&quot;:&quot;NBA_2017_18_CHA\/NBA_2017_18_CHA.png&quot;,&quot;ladodaluz&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;ракета&quot;:&quot;rocket_IW_2018_v2\/rocket_IW_2018_v2.png&quot;,&quot;timestone&quot;:&quot;drstrange_IW_2018_v2\/drstrange_IW_2018_v2.png&quot;,&quot;visao&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;iamgroot&quot;:&quot;groot_IW_2018_v2\/groot_IW_2018_v2.png&quot;,&quot;rockets&quot;:&quot;NBA_2017_18_HOU\/NBA_2017_18_HOU.png&quot;,&quot;dancingonice&quot;:&quot;DancingOnIce2018\/DancingOnIce2018.png&quot;,&quot;naciónporg&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;baftas&quot;:&quot;BAFTA\/BAFTA.png&quot;,&quot;soldatodinverno&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;lavisión&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;jurassicpark&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;greysanatomyfinale&quot;:&quot;TGIT_Meredith_2017_v4\/TGIT_Meredith_2017_v4.png&quot;,&quot;3percentsb&quot;:&quot;3percentConf-v2\/3percentConf-v2.png&quot;,&quot;revezamentodatocha&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;esseemeunatal&quot;:&quot;Natura_X-tmas_emoji_V3\/Natura_X-tmas_emoji_V3.png&quot;,&quot;祝アニナナ&quot;:&quot;idolish7_emoji\/idolish7_emoji.png&quot;,&quot;quickenloans&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;colonelsanders&quot;:&quot;KFC_Smoky_Mountain_BBQ_v2\/KFC_Smoky_Mountain_BBQ_v2.png&quot;,&quot;visión&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;국가대표칭찬해&quot;:&quot;WinterOlympics_KoreanMinistry\/WinterOlympics_KoreanMinistry.png&quot;,&quot;thedisasterartist&quot;:&quot;The_Disaster_Artist_v2\/The_Disaster_Artist_v2.png&quot;,&quot;эстафетаолимпийскогоогня&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;thevision&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;ポッキープリッツの日&quot;:&quot;PockyJPN_1111_Emoji_v3\/PockyJPN_1111_Emoji_v3.png&quot;,&quot;notdelivery&quot;:&quot;digiornonotdelivery\/digiornonotdelivery.png&quot;,&quot;100txrocketmortgage&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;가자평창&quot;:&quot;WinterOlympics_KoreanMinistry\/WinterOlympics_KoreanMinistry.png&quot;,&quot;gladiatorsout&quot;:&quot;TGIT_Scandal_2017_v3\/TGIT_Scandal_2017_v3.png&quot;,&quot;greysanatomy&quot;:&quot;TGIT_Meredith_2017_v4\/TGIT_Meredith_2017_v4.png&quot;,&quot;wethenorth&quot;:&quot;NBA_2017_18_TOR\/NBA_2017_18_TOR.png&quot;,&quot;punisher&quot;:&quot;The_Punisher_Emoji\/The_Punisher_Emoji.png&quot;,&quot;darkside&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;ihaveadream&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;الخيار_الذكي&quot;:&quot;ZainKSA\/ZainKSA.png&quot;,&quot;htgawmabc&quot;:&quot;TGIT_HTGAWM_2017_v3\/TGIT_HTGAWM_2017_v3.png&quot;,&quot;kyrieirving&quot;:&quot;KyrieIrving\/KyrieIrving.png&quot;,&quot;damianlillard&quot;:&quot;DamianLillardv2\/DamianLillardv2.png&quot;,&quot;rockygi&quot;:&quot;rocket_IW_2018_v2\/rocket_IW_2018_v2.png&quot;,&quot;スターウォーズep8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;mammamiamovie&quot;:&quot;MammaMia2\/MammaMia2.png&quot;,&quot;codwwii&quot;:&quot;CODWWII_emoji\/CODWWII_emoji.png&quot;,&quot;monsterhunterworld&quot;:&quot;MHW_2018\/MHW_2018.png&quot;,&quot;gospursgo&quot;:&quot;NBA_2017_18_SAS\/NBA_2017_18_SAS.png&quot;,&quot;coronacapital17&quot;:&quot;Corona_Capital_17_Emoji\/Corona_Capital_17_Emoji.png&quot;,&quot;downtowndubai&quot;:&quot;Emaar_Emoji_v4\/Emaar_Emoji_v4.png&quot;,&quot;порги&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;dubnation&quot;:&quot;NBA_2017_18_GSW\/NBA_2017_18_GSW.png&quot;,&quot;avidaéumafesta&quot;:&quot;Coco_Emoji\/Coco_Emoji.png&quot;,&quot;マンティス&quot;:&quot;mantis_IW_2018\/mantis_IW_2018.png&quot;,&quot;небула&quot;:&quot;nebula_IW_2018\/nebula_IW_2018.png&quot;,&quot;starwars&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;panteranegra&quot;:&quot;blackpanther_IW_2018\/blackpanther_IW_2018.png&quot;,&quot;takenote&quot;:&quot;NBA_2017_18_UTA\/NBA_2017_18_UTA.png&quot;,&quot;gopats&quot;:&quot;NFL_2017_NEPatriots_v3\/NFL_2017_NEPatriots_v3.png&quot;,&quot;goknowtakecontrol&quot;:&quot;Cigna_Emoji\/Cigna_Emoji.png&quot;,&quot;thefour&quot;:&quot;Fox_The_Four\/Fox_The_Four.png&quot;,&quot;episodio8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;tommywiseau&quot;:&quot;The_Disaster_Artist_v2\/The_Disaster_Artist_v2.png&quot;,&quot;올림픽성화봉송&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;زين_هنا&quot;:&quot;ZainKSA\/ZainKSA.png&quot;,&quot;gowinx&quot;:&quot;Tab_Winx_Emoji_v3\/Tab_Winx_Emoji_v3.png&quot;,&quot;olaftautauf&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;greysfinale&quot;:&quot;TGIT_Meredith_2017_v4\/TGIT_Meredith_2017_v4.png&quot;,&quot;blackpanther&quot;:&quot;blackpanther_IW_2018\/blackpanther_IW_2018.png&quot;,&quot;riverdale&quot;:&quot;RiverdaleS2_2018\/RiverdaleS2_2018.png&quot;,&quot;ラブクロ&quot;:&quot;LoveKuro\/LoveKuro.png&quot;,&quot;teamkorea&quot;:&quot;WinterOlympics_KoreanMinistry\/WinterOlympics_KoreanMinistry.png&quot;,&quot;owl2018&quot;:&quot;Overwatch_League_Launch\/Overwatch_League_Launch.png&quot;,&quot;スター・ウォーズ最後のジェダイ&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;mlk18&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;pacers&quot;:&quot;NBA_2017_18_IND\/NBA_2017_18_IND.png&quot;,&quot;ブラックパンサー&quot;:&quot;blackpanther_IW_2018\/blackpanther_IW_2018.png&quot;,&quot;theresidentonfox&quot;:&quot;Resident_FOX_emoji_v2\/Resident_FOX_emoji_v2.png&quot;,&quot;autoexpo18&quot;:&quot;Auto_expo\/Auto_expo.png&quot;,&quot;sb52&quot;:&quot;SuperBowl2018\/SuperBowl2018.png&quot;,&quot;mindstone&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;thestrangers&quot;:&quot;thestrangers\/thestrangers.png&quot;,&quot;blackmonuments&quot;:&quot;micblackmonuments2018\/micblackmonuments2018.png&quot;,&quot;capitánamérica&quot;:&quot;captainamerica_IW_2018\/captainamerica_IW_2018.png&quot;,&quot;giannisantetokounmpo&quot;:&quot;Giannisv2\/Giannisv2.png&quot;,&quot;superbowl&quot;:&quot;SuperBowl2018\/SuperBowl2018.png&quot;,&quot;aecompshow18&quot;:&quot;Auto_expo\/Auto_expo.png&quot;,&quot;911onfox&quot;:&quot;911_Fox\/911_Fox.png&quot;,&quot;mytwitteranniversary&quot;:&quot;MyTwitterAnniversary\/MyTwitterAnniversary.png&quot;,&quot;teamcap&quot;:&quot;captainamerica_IW_2018\/captainamerica_IW_2018.png&quot;,&quot;дроиды&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;thebachelorfinale&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;loki&quot;:&quot;Loki_IW_2018\/Loki_IW_2018.png&quot;,&quot;losúltimosjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;superboost&quot;:&quot;SuperBoost_emoji\/SuperBoost_emoji.png&quot;,&quot;nbbnotwitter&quot;:&quot;Emoji_NBB_2017_2018\/Emoji_NBB_2017_2018.png&quot;,&quot;平和オリンピック&quot;:&quot;Peace_Olympics_EMOJI_v3\/Peace_Olympics_EMOJI_v3.png&quot;,&quot;doctorstephenstrange&quot;:&quot;drstrange_IW_2018_v2\/drstrange_IW_2018_v2.png&quot;,&quot;mtnbrightside&quot;:&quot;MTN_BrightSide_Emoji\/MTN_BrightSide_Emoji.png&quot;,&quot;cheddarlive&quot;:&quot;Cheddar_Emoji_v4\/Cheddar_Emoji_v4.png&quot;,&quot;overwatchleague&quot;:&quot;Overwatch_League_Launch\/Overwatch_League_Launch.png&quot;,&quot;cgds4&quot;:&quot;CelebsGoDating2018\/CelebsGoDating2018.png&quot;,&quot;htgawmfinale&quot;:&quot;TGIT_HTGAWM_2017_v3\/TGIT_HTGAWM_2017_v3.png&quot;,&quot;bringithome&quot;:&quot;NFL_2017_MINVikings_v3\/NFL_2017_MINVikings_v3.png&quot;,&quot;doutorestranho&quot;:&quot;drstrange_IW_2018_v2\/drstrange_IW_2018_v2.png&quot;,&quot;stephcurry&quot;:&quot;StephenCurryv2\/StephenCurryv2.png&quot;,&quot;falcao&quot;:&quot;falcon_IW_2018\/falcon_IW_2018.png&quot;,&quot;spiderman&quot;:&quot;spiderman_IW_2018\/spiderman_IW_2018.png&quot;,&quot;mnwild&quot;:&quot;NHL_2017_2018_MNwild\/NHL_2017_2018_MNwild.png&quot;,&quot;primoordine&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;ヴィジョン&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;порг&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;toomanystars&quot;:&quot;HBONightofTooManyStars\/HBONightofTooManyStars.png&quot;,&quot;honkytonkcolonel&quot;:&quot;KFC_Smoky_Mountain_BBQ_v2\/KFC_Smoky_Mountain_BBQ_v2.png&quot;,&quot;olympictorchrelay&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;teampaolasascha&quot;:&quot;Amazon_Niche_Grand_Paola_v3\/Amazon_Niche_Grand_Paola_v3.png&quot;,&quot;viúvanegra&quot;:&quot;blackwidow_IW_2018\/blackwidow_IW_2018.png&quot;,&quot;mtndewice&quot;:&quot;Mountain_Dew_2018_SuperBowl\/Mountain_Dew_2018_SuperBowl.png&quot;,&quot;teamunited&quot;:&quot;United_Winter_Olympics_2018V2\/United_Winter_Olympics_2018V2.png&quot;,&quot;letsgoducks&quot;:&quot;NHL_2017_2018_Ducks\/NHL_2017_2018_Ducks.png&quot;,&quot;starwarsep8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;ウィンターソルジャー&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;スターウォーズ&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;laprimeraorden&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;digiornonotdelivery&quot;:&quot;digiornonotdelivery\/digiornonotdelivery.png&quot;,&quot;thelastjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;nyr&quot;:&quot;NHL_2017_2018_Buff_NYRangers\/NHL_2017_2018_Buff_NYRangers.png&quot;,&quot;jumanjigame&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;bucky&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;derniersjed&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;hulk&quot;:&quot;hulk_IW_2018_v2\/hulk_IW_2018_v2.png&quot;,&quot;nbaallstar&quot;:&quot;NBAAllStar\/NBAAllStar.png&quot;,&quot;webslinger&quot;:&quot;spiderman_IW_2018\/spiderman_IW_2018.png&quot;,&quot;ultimojedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;гамора&quot;:&quot;gamora_IW_2018_v3\/gamora_IW_2018_v3.png&quot;,&quot;samanthabee&quot;:&quot;Full_Frontal_Emoji\/Full_Frontal_Emoji.png&quot;,&quot;visão&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;сокол&quot;:&quot;falcon_IW_2018\/falcon_IW_2018.png&quot;,&quot;peterparker&quot;:&quot;spiderman_IW_2018\/spiderman_IW_2018.png&quot;,&quot;gooddeedscup&quot;:&quot;Chevrolet_Canada_Good_Deeds_Cup\/Chevrolet_Canada_Good_Deeds_Cup.png&quot;,&quot;greysabc&quot;:&quot;TGIT_Meredith_2017_v4\/TGIT_Meredith_2017_v4.png&quot;,&quot;super6&quot;:&quot;Super6_emoji\/Super6_emoji.png&quot;,&quot;allforone&quot;:&quot;NBA_2017_18_CLE\/NBA_2017_18_CLE.png&quot;,&quot;flyeaglesfly&quot;:&quot;NFL_2017_PHILEagles_v3\/NFL_2017_PHILEagles_v3.png&quot;,&quot;スパイダーマン&quot;:&quot;spiderman_IW_2018\/spiderman_IW_2018.png&quot;,&quot;togetherforgreen&quot;:&quot;Coca-Cola_World_Cup\/Coca-Cola_World_Cup.png&quot;,&quot;playjumanji&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;ladooscuro&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;teamcigna&quot;:&quot;Cigna_Emoji\/Cigna_Emoji.png&quot;,&quot;ダークサイド&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;colonelreba&quot;:&quot;KFC_Smoky_Mountain_BBQ_v2\/KFC_Smoky_Mountain_BBQ_v2.png&quot;,&quot;kfcbbq&quot;:&quot;KFC_Smoky_Mountain_BBQ_v2\/KFC_Smoky_Mountain_BBQ_v2.png&quot;,&quot;proudmary&quot;:&quot;Proud_Mary_Movie_Emoji_v3\/Proud_Mary_Movie_Emoji_v3.png&quot;,&quot;mhworld&quot;:&quot;MHW_2018\/MHW_2018.png&quot;,&quot;bbhate&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;tchalla&quot;:&quot;blackpanther_IW_2018\/blackpanther_IW_2018.png&quot;,&quot;ドロイド&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;blackmonumentsproject&quot;:&quot;micblackmonuments2018\/micblackmonuments2018.png&quot;,&quot;starwarsepviii&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;alltogethernowstl&quot;:&quot;NHL_2017_2018_STL_Blues\/NHL_2017_2018_STL_Blues.png&quot;,&quot;sanremo2018&quot;:&quot;TIM_Sanremo_2018-v3\/TIM_Sanremo_2018-v3.png&quot;,&quot;thebachelor&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;relevodelaantorchaolímpica&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;njdevils&quot;:&quot;NHL_2017_2018_NJDevils\/NHL_2017_2018_NJDevils.png&quot;,&quot;franciscoenperu&quot;:&quot;Pope_Chile_Peru\/Pope_Chile_Peru.png&quot;,&quot;alienisttnt&quot;:&quot;TNT-Alienist\/TNT-Alienist.png&quot;,&quot;westworldhbo&quot;:&quot;Westworld2\/Westworld2.png&quot;,&quot;afterthefinalrose&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;nbcutorchrelay&quot;:&quot;NBCU_Torch_Relay\/NBCU_Torch_Relay.png&quot;,&quot;cocoilfilm&quot;:&quot;Coco_Emoji\/Coco_Emoji.png&quot;,&quot;preparefordisaster&quot;:&quot;The_Disaster_Artist_v2\/The_Disaster_Artist_v2.png&quot;,&quot;netneutrality&quot;:&quot;Net_Emoji_v3\/Net_Emoji_v3.png&quot;,&quot;wckd&quot;:&quot;MazeRunner2\/MazeRunner2.png&quot;,&quot;우리선수&quot;:&quot;WinterOlympics_KoreanMinistry\/WinterOlympics_KoreanMinistry.png&quot;,&quot;thealienisttnt&quot;:&quot;TNT-Alienist\/TNT-Alienist.png&quot;,&quot;stephenstrange&quot;:&quot;drstrange_IW_2018_v2\/drstrange_IW_2018_v2.png&quot;,&quot;amtodmbf&quot;:&quot;BuzzFeedMorning_v3\/BuzzFeedMorning_v3.png&quot;,&quot;giannis&quot;:&quot;Giannisv2\/Giannisv2.png&quot;,&quot;helleseite&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;winjoethemug&quot;:&quot;GiveJoeABreak\/GiveJoeABreak.png&quot;,&quot;popbuzzpresents&quot;:&quot;PopbuzzPresents_Emoji\/PopbuzzPresents_Emoji.png&quot;,&quot;cignaruntogether&quot;:&quot;Cigna_Emoji\/Cigna_Emoji.png&quot;,&quot;オリンピック聖火&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;proudmarymovie&quot;:&quot;Proud_Mary_Movie_Emoji_v3\/Proud_Mary_Movie_Emoji_v3.png&quot;,&quot;chamaolimpica&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;чёрнаяпантера&quot;:&quot;blackpanther_IW_2018\/blackpanther_IW_2018.png&quot;,&quot;letztenjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;sacramentoproud&quot;:&quot;NBA_2017_18_SAC\/NBA_2017_18_SAC.png&quot;,&quot;キャプテンアメリカ&quot;:&quot;captainamerica_IW_2018\/captainamerica_IW_2018.png&quot;,&quot;thunderup&quot;:&quot;NBA_2017_18_OKC\/NBA_2017_18_OKC.png&quot;,&quot;nbatwitter&quot;:&quot;NBATwitter_Emoji___v4\/NBATwitter_Emoji___v4.png&quot;,&quot;drax&quot;:&quot;drax_IW_2018\/drax_IW_2018.png&quot;,&quot;disneyfrozen&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;getoutmovie&quot;:&quot;GetOutMovie\/GetOutMovie.png&quot;,&quot;スター・ウォーズ&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;abbepierre&quot;:&quot;FR_Fondation_Abbe_Pierre_EMOJI\/FR_Fondation_Abbe_Pierre_EMOJI.png&quot;,&quot;f4glory&quot;:&quot;Euroleague_2018_v2\/Euroleague_2018_v2.png&quot;,&quot;celebsgodating&quot;:&quot;CelebsGoDating2018\/CelebsGoDating2018.png&quot;,&quot;celebsgodatingseries4&quot;:&quot;CelebsGoDating2018\/CelebsGoDating2018.png&quot;,&quot;dcfamily&quot;:&quot;NBA_2017_18_WAS\/NBA_2017_18_WAS.png&quot;,&quot;gotg&quot;:&quot;starlord_IW_2018_v2\/starlord_IW_2018_v2.png&quot;,&quot;starwarsepisode8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;lastjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;ارامكو&quot;:&quot;Aramco_emoji\/Aramco_emoji.png&quot;,&quot;theresident&quot;:&quot;Resident_FOX_emoji_v2\/Resident_FOX_emoji_v2.png&quot;,&quot;coronacapital&quot;:&quot;Corona_Capital_17_Emoji\/Corona_Capital_17_Emoji.png&quot;,&quot;captainamerica&quot;:&quot;captainamerica_IW_2018\/captainamerica_IW_2018.png&quot;,&quot;дроид&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;altcarb&quot;:&quot;AlteredCarbon\/AlteredCarbon.png&quot;,&quot;xfiles&quot;:&quot;X-Files\/X-Files.png&quot;,&quot;アナ雪家族の思い出&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;dieletztenjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;celtics&quot;:&quot;NBA_2017_18_BOS\/NBA_2017_18_BOS.png&quot;,&quot;fitsyourlife&quot;:&quot;FitsYourLife\/FitsYourLife.png&quot;,&quot;olympicflame&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;アイアンマン&quot;:&quot;ironman_IW_2018_v3\/ironman_IW_2018_v3.png&quot;,&quot;いろはす白桃&quot;:&quot;CocaColaJapanPeach\/CocaColaJapanPeach.png&quot;,&quot;heygoogle&quot;:&quot;Google_Assistant\/Google_Assistant.png&quot;,&quot;aramco&quot;:&quot;Aramco_emoji\/Aramco_emoji.png&quot;,&quot;newsroomapp&quot;:&quot;NewsroomApp\/NewsroomApp.png&quot;,&quot;ブラックウィドウ&quot;:&quot;blackwidow_IW_2018\/blackwidow_IW_2018.png&quot;,&quot;esseehmeunatal&quot;:&quot;Natura_X-tmas_emoji_V3\/Natura_X-tmas_emoji_V3.png&quot;,&quot;ビービーナインイー&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;homemdeferro&quot;:&quot;ironman_IW_2018_v3\/ironman_IW_2018_v3.png&quot;,&quot;kylelowry&quot;:&quot;KyleLowryv2\/KyleLowryv2.png&quot;,&quot;firstorder&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;buckybarnes&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;kentuckyfriedchicken&quot;:&quot;KFC_Smoky_Mountain_BBQ_v2\/KFC_Smoky_Mountain_BBQ_v2.png&quot;,&quot;monsterhunter&quot;:&quot;MHW_2018\/MHW_2018.png&quot;,&quot;lobsterfest&quot;:&quot;Red_Lobster_Next_Gen\/Red_Lobster_Next_Gen.png&quot;,&quot;和平奥运会&quot;:&quot;Peace_Olympics_EMOJI_v3\/Peace_Olympics_EMOJI_v3.png&quot;,&quot;thedebut&quot;:&quot;TheDebut\/TheDebut.png&quot;,&quot;xfilesbinge&quot;:&quot;X-Files\/X-Files.png&quot;,&quot;グルート&quot;:&quot;groot_IW_2018_v2\/groot_IW_2018_v2.png&quot;,&quot;soldadoinvernal&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;mffl&quot;:&quot;NBA_2017_18_DAL\/NBA_2017_18_DAL.png&quot;,&quot;goboldly&quot;:&quot;PhRMA\/PhRMA.png&quot;,&quot;marthavjib&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;freshevents&quot;:&quot;Fresh_Empire_Q1_2018_v2\/Fresh_Empire_Q1_2018_v2.png&quot;,&quot;isles&quot;:&quot;NHL_2017_2018_NYIslanders\/NHL_2017_2018_NYIslanders.png&quot;,&quot;primeraorden&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;リメンバーミー&quot;:&quot;Coco_Emoji\/Coco_Emoji.png&quot;,&quot;kfc&quot;:&quot;KFC_Smoky_Mountain_BBQ_v2\/KFC_Smoky_Mountain_BBQ_v2.png&quot;,&quot;doritosblaze&quot;:&quot;Doritos_superbowl_2018\/Doritos_superbowl_2018.png&quot;,&quot;lightup2018&quot;:&quot;Emaar_Emoji_v4\/Emaar_Emoji_v4.png&quot;,&quot;ultimijedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;thephantomoftheopera&quot;:&quot;PhantomofTheOpera_2018\/PhantomofTheOpera_2018.png&quot;,&quot;bbneuf&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;starwarsgliultimijedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;am2dm&quot;:&quot;BuzzFeedMorning_v3\/BuzzFeedMorning_v3.png&quot;,&quot;brucebanner&quot;:&quot;hulk_IW_2018_v2\/hulk_IW_2018_v2.png&quot;,&quot;porgnation&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;disasterartist&quot;:&quot;The_Disaster_Artist_v2\/The_Disaster_Artist_v2.png&quot;,&quot;kingday50&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;starwarsthelastjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;justintimberlake&quot;:&quot;JustinTimberlake_MOTW\/JustinTimberlake_MOTW.png&quot;,&quot;ultimosjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;brits&quot;:&quot;BRITsOverall2018\/BRITsOverall2018.png&quot;,&quot;viudanegra&quot;:&quot;blackwidow_IW_2018\/blackwidow_IW_2018.png&quot;,&quot;scanda7&quot;:&quot;TGIT_Scandal_2017_v3\/TGIT_Scandal_2017_v3.png&quot;,&quot;ubsart&quot;:&quot;Art_Basel_branded_emoji\/Art_Basel_branded_emoji.png&quot;,&quot;aetms&quot;:&quot;Auto_expo\/Auto_expo.png&quot;,&quot;closelangtocloserpa&quot;:&quot;CloseupValentinesDay\/CloseupValentinesDay.png&quot;,&quot;vision&quot;:&quot;vision_IW_2018_v2\/vision_IW_2018_v2.png&quot;,&quot;grindcity&quot;:&quot;NBA_2017_18_MEM\/NBA_2017_18_MEM.png&quot;,&quot;nowyoureinthesunkenplace&quot;:&quot;GetOutMovie\/GetOutMovie.png&quot;,&quot;gladiatorsabc&quot;:&quot;TGIT_Scandal_2017_v3\/TGIT_Scandal_2017_v3.png&quot;,&quot;ファルコン&quot;:&quot;falcon_IW_2018\/falcon_IW_2018.png&quot;,&quot;iamproud&quot;:&quot;Proud_Mary_Movie_Emoji_v3\/Proud_Mary_Movie_Emoji_v3.png&quot;,&quot;blackheroes&quot;:&quot;micblackmonuments2018\/micblackmonuments2018.png&quot;,&quot;blackwidow&quot;:&quot;blackwidow_IW_2018\/blackwidow_IW_2018.png&quot;,&quot;drstephenstrange&quot;:&quot;drstrange_IW_2018_v2\/drstrange_IW_2018_v2.png&quot;,&quot;lgrw&quot;:&quot;NHL_2017_2018_DetroitRW\/NHL_2017_2018_DetroitRW.png&quot;,&quot;wavo&quot;:&quot;Wavo_Emoji\/Wavo_Emoji.png&quot;,&quot;martinlutherkingjr&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;jurassicpark25&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;karlanthonytowns&quot;:&quot;KarlAnthonyTownsv2\/KarlAnthonyTownsv2.png&quot;,&quot;олимпийскийогонь&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;soompiawards&quot;:&quot;Soompi_awards_2018\/Soompi_awards_2018.png&quot;,&quot;abbépierre&quot;:&quot;FR_Fondation_Abbe_Pierre_EMOJI\/FR_Fondation_Abbe_Pierre_EMOJI.png&quot;,&quot;олафихолодноеприключние&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;mlkday&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;mustachemeanything&quot;:&quot;MurderOrientExpress_emoji1_Mustache_v2\/MurderOrientExpress_emoji1_Mustache_v2.png&quot;,&quot;mamamia2&quot;:&quot;MammaMia2\/MammaMia2.png&quot;,&quot;dunkleseite&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;homemaranha&quot;:&quot;spiderman_IW_2018\/spiderman_IW_2018.png&quot;,&quot;goduster&quot;:&quot;Dacia_Duster_v3\/Dacia_Duster_v3.png&quot;,&quot;最後のジェダイ&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;lobsterfestgoals&quot;:&quot;Red_Lobster_Next_Gen\/Red_Lobster_Next_Gen.png&quot;,&quot;navidadilimitada&quot;:&quot;Emoji_Dimitree_Entel\/Emoji_Dimitree_Entel.png&quot;,&quot;doramilaje&quot;:&quot;okoye_IW_2018\/okoye_IW_2018.png&quot;,&quot;thefouronfox&quot;:&quot;Fox_The_Four\/Fox_The_Four.png&quot;,&quot;звездныйлорд&quot;:&quot;starlord_IW_2018_v2\/starlord_IW_2018_v2.png&quot;,&quot;scarletwitch&quot;:&quot;Scarlet_Witch\/Scarlet_Witch.png&quot;,&quot;ドラックス&quot;:&quot;drax_IW_2018\/drax_IW_2018.png&quot;,&quot;truetoatlanta&quot;:&quot;NBA_2017_18_ATL\/NBA_2017_18_ATL.png&quot;,&quot;jamesharden&quot;:&quot;JamesHardenv2\/JamesHardenv2.png&quot;,&quot;relevodelaantorchaolimpica&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;iktva&quot;:&quot;Aramco_emoji\/Aramco_emoji.png&quot;,&quot;エピソード8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;orientexpressmovie&quot;:&quot;Murder_Orient_Express_Emoji_Magnifying_Glass\/Murder_Orient_Express_Emoji_Magnifying_Glass.png&quot;,&quot;martinlutherking&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;baftas2018&quot;:&quot;BAFTA\/BAFTA.png&quot;,&quot;demarcuscousins&quot;:&quot;DeMarcusCousinsv2\/DeMarcusCousinsv2.png&quot;,&quot;proudmother&quot;:&quot;Proud_Mary_Movie_Emoji_v3\/Proud_Mary_Movie_Emoji_v3.png&quot;,&quot;blackhawks&quot;:&quot;NHL_2017_2018_Blackhawks\/NHL_2017_2018_Blackhawks.png&quot;,&quot;rocketelmapache&quot;:&quot;rocket_IW_2018_v2\/rocket_IW_2018_v2.png&quot;,&quot;私にとって平和とは&quot;:&quot;Peace_Olympics_EMOJI_v3\/Peace_Olympics_EMOJI_v3.png&quot;,&quot;flammeolympique&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;pazparami&quot;:&quot;Peace_Olympics_EMOJI_v3\/Peace_Olympics_EMOJI_v3.png&quot;,&quot;sjsharks&quot;:&quot;NHL_2017_2018_SJSharks\/NHL_2017_2018_SJSharks.png&quot;,&quot;scandalabc&quot;:&quot;TGIT_Scandal_2017_v3\/TGIT_Scandal_2017_v3.png&quot;,&quot;ultimajedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;majorconfidence&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;lightside&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;joelembiid&quot;:&quot;JoelEmbiidv2\/JoelEmbiidv2.png&quot;,&quot;bestofus&quot;:&quot;BestOfUs\/BestOfUs.png&quot;,&quot;martinlutherkingjrday&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;jumanjijungle&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;sunsat50&quot;:&quot;NBA_2017_18_PHX\/NBA_2017_18_PHX.png&quot;,&quot;jughead&quot;:&quot;RiverdaleS2_2018\/RiverdaleS2_2018.png&quot;,&quot;tissuetuesdays&quot;:&quot;This_Is_Us_Mid_2018\/This_Is_Us_Mid_2018.png&quot;,&quot;زين_السعودية&quot;:&quot;ZainKSA\/ZainKSA.png&quot;,&quot;victoroladipo&quot;:&quot;VictorOladipov2\/VictorOladipov2.png&quot;,&quot;nebulaiw&quot;:&quot;nebula_IW_2018\/nebula_IW_2018.png&quot;,&quot;whyiwearawhiterose&quot;:&quot;White_Rose_Grammys_v2\/White_Rose_Grammys_v2.png&quot;,&quot;jurassicworld&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;arieluyendykjr&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;itsnotdeliveryitsdigiorno&quot;:&quot;digiornonotdelivery\/digiornonotdelivery.png&quot;,&quot;olafotraaventuracongeladadefrozen&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;pixarcoco&quot;:&quot;Coco_Emoji\/Coco_Emoji.png&quot;,&quot;gostars&quot;:&quot;NHL_2017_2018_DStars\/NHL_2017_2018_DStars.png&quot;,&quot;thepunisher&quot;:&quot;The_Punisher_Emoji\/The_Punisher_Emoji.png&quot;,&quot;marthavsjack&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;nyevegasstyle&quot;:&quot;MGM_NYE_2017\/MGM_NYE_2017.png&quot;,&quot;wintersoldier&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;lobsterworthy&quot;:&quot;Red_Lobster_Next_Gen\/Red_Lobster_Next_Gen.png&quot;,&quot;pepsihalftime&quot;:&quot;Pepsi_Halftime_SuperBowl_2018_v2\/Pepsi_Halftime_SuperBowl_2018_v2.png&quot;,&quot;mlk2018&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;mhw&quot;:&quot;MHW_2018\/MHW_2018.png&quot;,&quot;appleeduchat&quot;:&quot;AppleEDUChat_v2\/AppleEDUChat_v2.png&quot;,&quot;vwtroc&quot;:&quot;VW_Troc\/VW_Troc.png&quot;,&quot;redvolution&quot;:&quot;NHL_2017_2018_CarolinaCanes\/NHL_2017_2018_CarolinaCanes.png&quot;,&quot;breathetrailer&quot;:&quot;Amazon_Breathe\/Amazon_Breathe.png&quot;,&quot;flapanthers&quot;:&quot;NHL_2017_2018_FlaPanthers\/NHL_2017_2018_FlaPanthers.png&quot;,&quot;womentellall&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;fondationabbépierre&quot;:&quot;FR_Fondation_Abbe_Pierre_EMOJI\/FR_Fondation_Abbe_Pierre_EMOJI.png&quot;,&quot;jamesmay&quot;:&quot;The_Grand_Tour_May_Emoji\/The_Grand_Tour_May_Emoji.png&quot;,&quot;theincrediblehulk&quot;:&quot;hulk_IW_2018_v2\/hulk_IW_2018_v2.png&quot;,&quot;ladodelaluz&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;osultimosjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;freshempire&quot;:&quot;Fresh_Empire_Q1_2018_v2\/Fresh_Empire_Q1_2018_v2.png&quot;,&quot;anthonydavis&quot;:&quot;AnthonyDavisv2\/AnthonyDavisv2.png&quot;,&quot;myblackmonument&quot;:&quot;micblackmonuments2018\/micblackmonuments2018.png&quot;,&quot;whiteroses4music&quot;:&quot;White_Rose_Grammys_v2\/White_Rose_Grammys_v2.png&quot;,&quot;heforshe&quot;:&quot;HeForShe_fixed\/HeForShe_fixed.png&quot;,&quot;شيّرها&quot;:&quot;ZainKSA\/ZainKSA.png&quot;,&quot;7candal&quot;:&quot;TGIT_Scandal_2017_v3\/TGIT_Scandal_2017_v3.png&quot;,&quot;uberindia&quot;:&quot;UberIndia_Q4_17\/UberIndia_Q4_17.png&quot;,&quot;franciscoenperú&quot;:&quot;Pope_Chile_Peru\/Pope_Chile_Peru.png&quot;,&quot;thisisus&quot;:&quot;This_Is_Us_Mid_2018\/This_Is_Us_Mid_2018.png&quot;,&quot;hereweare&quot;:&quot;HereWeAre_v3\/HereWeAre_v3.png&quot;,&quot;heatculture&quot;:&quot;NBA_2017_18_MIA\/NBA_2017_18_MIA.png&quot;,&quot;ligadia&quot;:&quot;LigaDia_Emoji_v2\/LigaDia_Emoji_v2.png&quot;,&quot;nebulosagi&quot;:&quot;nebula_IW_2018\/nebula_IW_2018.png&quot;,&quot;greatestshowman&quot;:&quot;Greatest_Showman_Emoji\/Greatest_Showman_Emoji.png&quot;,&quot;letsfootball&quot;:&quot;Indian_Super_League_Emoji\/Indian_Super_League_Emoji.png&quot;,&quot;beronica&quot;:&quot;RiverdaleS2_2018\/RiverdaleS2_2018.png&quot;,&quot;thegamethatplaysyou&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;мантис&quot;:&quot;mantis_IW_2018\/mantis_IW_2018.png&quot;,&quot;sabres&quot;:&quot;NHL_2017_2018_Buff_Sabres\/NHL_2017_2018_Buff_Sabres.png&quot;,&quot;lasuertenojuega&quot;:&quot;La_Suerte_No_Juega\/La_Suerte_No_Juega.png&quot;,&quot;jumanji&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;hagamosteamback&quot;:&quot;HagamosTeamBlack_v2\/HagamosTeamBlack_v2.png&quot;,&quot;докторстрэндж&quot;:&quot;drstrange_IW_2018_v2\/drstrange_IW_2018_v2.png&quot;,&quot;understandfully&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;brightsummer&quot;:&quot;MTN_BrightSide_Emoji\/MTN_BrightSide_Emoji.png&quot;,&quot;welcometowestworld&quot;:&quot;Westworld2\/Westworld2.png&quot;,&quot;whywewearblack&quot;:&quot;TimesUp\/TimesUp.png&quot;,&quot;alienist&quot;:&quot;TNT-Alienist\/TNT-Alienist.png&quot;,&quot;episodioviii&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;côtélumineux&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;varchie&quot;:&quot;RiverdaleS2_2018\/RiverdaleS2_2018.png&quot;,&quot;primeiraordem&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;andredrummond&quot;:&quot;Drummond\/Drummond.png&quot;,&quot;phantomoftheopera&quot;:&quot;PhantomofTheOpera_2018\/PhantomofTheOpera_2018.png&quot;,&quot;letsgopens&quot;:&quot;NHL_2017_2018_Penguins\/NHL_2017_2018_Penguins.png&quot;,&quot;jimmybutler&quot;:&quot;JimmyButlerv2\/JimmyButlerv2.png&quot;,&quot;sanremo18&quot;:&quot;TIM_Sanremo_2018-v3\/TIM_Sanremo_2018-v3.png&quot;,&quot;bbvawallet&quot;:&quot;BBVAWallet_emoji\/BBVAWallet_emoji.png&quot;,&quot;thesunkenplace&quot;:&quot;GetOutMovie\/GetOutMovie.png&quot;,&quot;jumanjimovie&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;wakandaforever&quot;:&quot;blackpanther_IW_2018\/blackpanther_IW_2018.png&quot;,&quot;エースリー満員御礼&quot;:&quot;mankaicompany\/mankaicompany.png&quot;,&quot;episodeviii&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;dodgedown&quot;:&quot;Dodge_Mexico_NFL_EMOJI\/Dodge_Mexico_NFL_EMOJI.png&quot;,&quot;nhlbruins&quot;:&quot;NHL_2017_2018_NHLBruins\/NHL_2017_2018_NHLBruins.png&quot;,&quot;blackhistorymonth&quot;:&quot;BlackHistoryMonth\/BlackHistoryMonth.png&quot;,&quot;sharethemoment&quot;:&quot;This_Is_Us_Mid_2018\/This_Is_Us_Mid_2018.png&quot;,&quot;평창올림픽성화봉송&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;starwarsbattlefrontii&quot;:&quot;EAStarWars_StarWarsBattlefrontII_Emoji\/EAStarWars_StarWarsBattlefrontII_Emoji.png&quot;,&quot;strongandproud&quot;:&quot;Proud_Mary_Movie_Emoji_v3\/Proud_Mary_Movie_Emoji_v3.png&quot;,&quot;droide&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;kevindurant&quot;:&quot;KevinDurant\/KevinDurant.png&quot;,&quot;spacestone&quot;:&quot;Loki_IW_2018\/Loki_IW_2018.png&quot;,&quot;vegasborn&quot;:&quot;NHL_2017_2018_VegasKnights_v2\/NHL_2017_2018_VegasKnights_v2.png&quot;,&quot;starwarsdieletztenjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;martinlutherkingday&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;mlkjrday&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;starwarsepisodioviii&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;getthismanashield&quot;:&quot;captainamerica_IW_2018\/captainamerica_IW_2018.png&quot;,&quot;metoo&quot;:&quot;MeToo_v3\/MeToo_v3.png&quot;,&quot;железныйчеловек&quot;:&quot;ironman_IW_2018_v3\/ironman_IW_2018_v3.png&quot;,&quot;relevodelaantorcha&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;amexcobalt&quot;:&quot;AmexCobalt_v2\/AmexCobalt_v2.png&quot;,&quot;wemetontwitter&quot;:&quot;WeMetOnt_Emoji\/WeMetOnt_Emoji.png&quot;,&quot;nbakicks&quot;:&quot;FootLocker-2018\/FootLocker-2018.png&quot;,&quot;ビービー8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;starkindustries&quot;:&quot;ironman_IW_2018_v3\/ironman_IW_2018_v3.png&quot;,&quot;tesseract&quot;:&quot;Loki_IW_2018\/Loki_IW_2018.png&quot;,&quot;droids&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;тайнакоко&quot;:&quot;Coco_Emoji\/Coco_Emoji.png&quot;,&quot;timesup4music&quot;:&quot;White_Rose_Grammys_v2\/White_Rose_Grammys_v2.png&quot;,&quot;fondationabbepierre&quot;:&quot;FR_Fondation_Abbe_Pierre_EMOJI\/FR_Fondation_Abbe_Pierre_EMOJI.png&quot;,&quot;modopapa&quot;:&quot;Pope_Chile_Peru\/Pope_Chile_Peru.png&quot;,&quot;undisputedchristmas&quot;:&quot;UndisputedXmas_emoji_v2\/UndisputedXmas_emoji_v2.png&quot;,&quot;jw2&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;dimitree&quot;:&quot;Emoji_Dimitree_Entel\/Emoji_Dimitree_Entel.png&quot;,&quot;いろはす白桃でリラックス&quot;:&quot;CocaColaJapanPeach\/CocaColaJapanPeach.png&quot;,&quot;thisisthepepsi&quot;:&quot;Pepsi_Halftime_SuperBowl_2018_v2\/Pepsi_Halftime_SuperBowl_2018_v2.png&quot;,&quot;mbcthevoicekids&quot;:&quot;MBC_The_Voice\/MBC_The_Voice.png&quot;,&quot;stillmarching&quot;:&quot;Votes_for_Women\/Votes_for_Women.png&quot;,&quot;theroom&quot;:&quot;The_Disaster_Artist_v2\/The_Disaster_Artist_v2.png&quot;,&quot;911fox&quot;:&quot;911_Fox\/911_Fox.png&quot;,&quot;эстафетаогня&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;westworlds2&quot;:&quot;Westworld2\/Westworld2.png&quot;,&quot;응원해요&quot;:&quot;WinterOlympics_KoreanMinistry\/WinterOlympics_KoreanMinistry.png&quot;,&quot;gorandragic&quot;:&quot;Dragicv2\/Dragicv2.png&quot;,&quot;welcometothejungle&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;guardiansofthegalaxy&quot;:&quot;groot_IW_2018_v2\/groot_IW_2018_v2.png&quot;,&quot;paulgeorge&quot;:&quot;PaulGeorge\/PaulGeorge.png&quot;,&quot;latovegasfox&quot;:&quot;Fox_LA_Vegas\/Fox_LA_Vegas.png&quot;,&quot;mlk50&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;yotes&quot;:&quot;NHL_2017_2018_Buff_Coyotes\/NHL_2017_2018_Buff_Coyotes.png&quot;,&quot;starwarslesderniersjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;ビットフライヤー&quot;:&quot;bitcoin_Emoji\/bitcoin_Emoji.png&quot;,&quot;wegohard&quot;:&quot;NBA_2017_18_BKLYN\/NBA_2017_18_BKLYN.png&quot;,&quot;newmenufeels&quot;:&quot;Red_Lobster_Next_Gen\/Red_Lobster_Next_Gen.png&quot;,&quot;jp25&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;motw&quot;:&quot;JustinTimberlake_MOTW\/JustinTimberlake_MOTW.png&quot;,&quot;тёмнаясторона&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;atfr&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;bellletstalk&quot;:&quot;BellLetsTalk\/BellLetsTalk.png&quot;,&quot;paixpourmoi&quot;:&quot;Peace_Olympics_EMOJI_v3\/Peace_Olympics_EMOJI_v3.png&quot;,&quot;johnwall&quot;:&quot;JohnWallv2\/JohnWallv2.png&quot;,&quot;euroleague&quot;:&quot;Euroleague_2018_v2\/Euroleague_2018_v2.png&quot;,&quot;droides&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;soldadodelinvierno&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;bhm&quot;:&quot;BlackHistoryMonth\/BlackHistoryMonth.png&quot;,&quot;우리선수화이팅&quot;:&quot;WinterOlympics_KoreanMinistry\/WinterOlympics_KoreanMinistry.png&quot;,&quot;звёздныевойны&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;idontplay&quot;:&quot;Proud_Mary_Movie_Emoji_v3\/Proud_Mary_Movie_Emoji_v3.png&quot;,&quot;capitaoamerica&quot;:&quot;captainamerica_IW_2018\/captainamerica_IW_2018.png&quot;,&quot;jumanji2017&quot;:&quot;Jumanji_Emoji\/Jumanji_Emoji.png&quot;,&quot;blackhero&quot;:&quot;micblackmonuments2018\/micblackmonuments2018.png&quot;,&quot;marthavsjackinthebox&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;thankyoumlk50&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;jacintheboxvmartha&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;porglife&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;gojetsgo&quot;:&quot;NHL_2017_2018_Jets\/NHL_2017_2018_Jets.png&quot;,&quot;smokymountaincolonel&quot;:&quot;KFC_Smoky_Mountain_BBQ_v2\/KFC_Smoky_Mountain_BBQ_v2.png&quot;,&quot;bullsnation&quot;:&quot;NBA_2017_18_CHI\/NBA_2017_18_CHI.png&quot;,&quot;crispypanpizza&quot;:&quot;digiornonotdelivery\/digiornonotdelivery.png&quot;,&quot;rathalos&quot;:&quot;MHW_2018\/MHW_2018.png&quot;,&quot;bafta2018&quot;:&quot;BAFTA\/BAFTA.png&quot;,&quot;олаф&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;ハルク&quot;:&quot;hulk_IW_2018_v2\/hulk_IW_2018_v2.png&quot;,&quot;mammamia2&quot;:&quot;MammaMia2\/MammaMia2.png&quot;,&quot;나에게평화란&quot;:&quot;Peace_Olympics_EMOJI_v3\/Peace_Olympics_EMOJI_v3.png&quot;,&quot;nobodylivesforever&quot;:&quot;AlteredCarbon\/AlteredCarbon.png&quot;,&quot;ネビュラiw&quot;:&quot;nebula_IW_2018\/nebula_IW_2018.png&quot;,&quot;burjkhalifa&quot;:&quot;Emaar_Emoji_v4\/Emaar_Emoji_v4.png&quot;,&quot;mlk&quot;:&quot;ThankYouMLK50\/ThankYouMLK50.png&quot;,&quot;nightoftoomanystars&quot;:&quot;HBONightofTooManyStars\/HBONightofTooManyStars.png&quot;,&quot;لا_يحدك_شي&quot;:&quot;ZainKSA\/ZainKSA.png&quot;,&quot;jurassicworld2&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;blacklivesmatter&quot;:&quot;BlackHistoryMonth\/BlackHistoryMonth.png&quot;,&quot;senhordasestrelas&quot;:&quot;starlord_IW_2018_v2\/starlord_IW_2018_v2.png&quot;,&quot;starlord&quot;:&quot;starlord_IW_2018_v2\/starlord_IW_2018_v2.png&quot;,&quot;westworldseason2&quot;:&quot;Westworld2\/Westworld2.png&quot;,&quot;legendaryoutlaw&quot;:&quot;starlord_IW_2018_v2\/starlord_IW_2018_v2.png&quot;,&quot;preds&quot;:&quot;NHL_2017_2018_Preds\/NHL_2017_2018_Preds.png&quot;,&quot;dillydilly&quot;:&quot;budlight_helmet\/budlight_helmet.png&quot;,&quot;ドクターストレンジ&quot;:&quot;drstrange_IW_2018_v2\/drstrange_IW_2018_v2.png&quot;,&quot;эпизод8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;bb9e&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;allcaps&quot;:&quot;NHL_2017_2018_Caps\/NHL_2017_2018_Caps.png&quot;,&quot;дракс&quot;:&quot;drax_IW_2018\/drax_IW_2018.png&quot;,&quot;revezamentodatochaolimpica&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;bbodio&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;smokymountainbbq&quot;:&quot;KFC_Smoky_Mountain_BBQ_v2\/KFC_Smoky_Mountain_BBQ_v2.png&quot;,&quot;milehighbasketball&quot;:&quot;NBA_2017_18_DEN_v2\/NBA_2017_18_DEN_v2.png&quot;,&quot;franciscoenchile&quot;:&quot;Pope_Chile_Peru\/Pope_Chile_Peru.png&quot;,&quot;karltowns&quot;:&quot;KarlAnthonyTownsv2\/KarlAnthonyTownsv2.png&quot;,&quot;frenchfab&quot;:&quot;France_BPI_v3\/France_BPI_v3.png&quot;,&quot;suerteono&quot;:&quot;La_Suerte_No_Juega\/La_Suerte_No_Juega.png&quot;,&quot;dundeetourismad&quot;:&quot;Tourism_Australia_Dundee_v5\/Tourism_Australia_Dundee_v5.png&quot;,&quot;draxthedestroyer&quot;:&quot;drax_IW_2018\/drax_IW_2018.png&quot;,&quot;okoye&quot;:&quot;okoye_IW_2018\/okoye_IW_2018.png&quot;,&quot;spidey&quot;:&quot;spiderman_IW_2018\/spiderman_IW_2018.png&quot;,&quot;ロキ&quot;:&quot;Loki_IW_2018\/Loki_IW_2018.png&quot;,&quot;starwarsepisodeviii&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;motwtour&quot;:&quot;JustinTimberlake_MOTW\/JustinTimberlake_MOTW.png&quot;,&quot;letsgooilers&quot;:&quot;NHL_2017_2018_Edmonton\/NHL_2017_2018_Edmonton.png&quot;,&quot;puremagic&quot;:&quot;NBA_2017_18_ORL\/NBA_2017_18_ORL.png&quot;,&quot;maquinadecombate&quot;:&quot;warmachine_IW_2018\/warmachine_IW_2018.png&quot;,&quot;soldatdelhiver&quot;:&quot;wintersoldier_IW_2018\/wintersoldier_IW_2018.png&quot;,&quot;starwarsosultimosjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;heretocreate&quot;:&quot;adidas_Burst_4_Emoji_v2\/adidas_Burst_4_Emoji_v2.png&quot;,&quot;スターロード&quot;:&quot;starlord_IW_2018_v2\/starlord_IW_2018_v2.png&quot;,&quot;локи&quot;:&quot;Loki_IW_2018\/Loki_IW_2018.png&quot;,&quot;ripcity&quot;:&quot;NBA_2017_18_POR\/NBA_2017_18_POR.png&quot;,&quot;mustachemeaquestion&quot;:&quot;MurderOrientExpress_emoji1_Mustache_v2\/MurderOrientExpress_emoji1_Mustache_v2.png&quot;,&quot;lakeshow&quot;:&quot;NBA_2017_18_LAL\/NBA_2017_18_LAL.png&quot;,&quot;unidosporlaesperanza&quot;:&quot;Pope_Chile_Peru\/Pope_Chile_Peru.png&quot;,&quot;episode8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;imadisasterartist&quot;:&quot;The_Disaster_Artist_v2\/The_Disaster_Artist_v2.png&quot;,&quot;sheinspiresme&quot;:&quot;HereWeAre_v3\/HereWeAre_v3.png&quot;,&quot;discoverwestworld&quot;:&quot;Westworld2\/Westworld2.png&quot;,&quot;stephencurry&quot;:&quot;StephenCurryv2\/StephenCurryv2.png&quot;,&quot;davidduchovny&quot;:&quot;X-Files\/X-Files.png&quot;,&quot;marthavjack&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;mydubainewyear&quot;:&quot;Emaar_Emoji_v4\/Emaar_Emoji_v4.png&quot;,&quot;первыйорден&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;lifefindsaway&quot;:&quot;Jurassic_World_emoji_v2\/Jurassic_World_emoji_v2.png&quot;,&quot;whiterose2018&quot;:&quot;White_Rose_Grammys_v2\/White_Rose_Grammys_v2.png&quot;,&quot;joyeusesfetesavecolaf&quot;:&quot;Olaf_Emoji\/Olaf_Emoji.png&quot;,&quot;聖火リレー&quot;:&quot;OlympicFlameEmoji\/OlympicFlameEmoji.png&quot;,&quot;fannfl&quot;:&quot;Fan_NFL_emoji_v2\/Fan_NFL_emoji_v2.png&quot;,&quot;tmltalk&quot;:&quot;NHL_2017_2018_MapleLeafs\/NHL_2017_2018_MapleLeafs.png&quot;,&quot;draymondgreen&quot;:&quot;DraymondGreenv2\/DraymondGreenv2.png&quot;,&quot;joethemug&quot;:&quot;GiveJoeABreak\/GiveJoeABreak.png&quot;,&quot;disneypixarcoco&quot;:&quot;Coco_Emoji\/Coco_Emoji.png&quot;,&quot;jibvsmartha&quot;:&quot;JackVSMartha\/JackVSMartha.png&quot;,&quot;droiden&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;ファーストオーダー&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;capitãoamérica&quot;:&quot;captainamerica_IW_2018\/captainamerica_IW_2018.png&quot;,&quot;светлаясторона&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;mortgageconfidently&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;htgawm&quot;:&quot;TGIT_HTGAWM_2017_v3\/TGIT_HTGAWM_2017_v3.png&quot;,&quot;ironman&quot;:&quot;ironman_IW_2018_v3\/ironman_IW_2018_v3.png&quot;,&quot;rocketraccoon&quot;:&quot;rocket_IW_2018_v2\/rocket_IW_2018_v2.png&quot;,&quot;máquinadeguerra&quot;:&quot;warmachine_IW_2018\/warmachine_IW_2018.png&quot;,&quot;starwarslosúltimosjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;bb8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;droidi&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;ウォーマシン&quot;:&quot;warmachine_IW_2018\/warmachine_IW_2018.png&quot;,&quot;mymtnsummer&quot;:&quot;MTN_BrightSide_Emoji\/MTN_BrightSide_Emoji.png&quot;,&quot;tonystark&quot;:&quot;ironman_IW_2018_v3\/ironman_IW_2018_v3.png&quot;,&quot;звёздныевойныэпизод8&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;viedeporg&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;tgit&quot;:&quot;TGIT_Popcorn_v2\/TGIT_Popcorn_v2.png&quot;,&quot;cheddarbaybiscuits&quot;:&quot;Red_Lobster_Next_Gen\/Red_Lobster_Next_Gen.png&quot;,&quot;steverogers&quot;:&quot;captainamerica_IW_2018\/captainamerica_IW_2018.png&quot;,&quot;ladosombrio&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;peace4me&quot;:&quot;Peace_Olympics_EMOJI_v3\/Peace_Olympics_EMOJI_v3.png&quot;,&quot;nbb&quot;:&quot;Emoji_NBB_2017_2018\/Emoji_NBB_2017_2018.png&quot;,&quot;クロノジェネシス&quot;:&quot;shadowverse_emoji\/shadowverse_emoji.png&quot;,&quot;ビービーエイト&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;soyonshumains&quot;:&quot;FR_Fondation_Abbe_Pierre_EMOJI\/FR_Fondation_Abbe_Pierre_EMOJI.png&quot;,&quot;дройд&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;máquinadecombate&quot;:&quot;warmachine_IW_2018\/warmachine_IW_2018.png&quot;,&quot;bughead&quot;:&quot;RiverdaleS2_2018\/RiverdaleS2_2018.png&quot;,&quot;bellcause&quot;:&quot;BellLetsTalk\/BellLetsTalk.png&quot;,&quot;olympictruce&quot;:&quot;Peace_Olympics_EMOJI_v3\/Peace_Olympics_EMOJI_v3.png&quot;,&quot;nflblitz&quot;:&quot;NFL_2017_Blitz_v2\/NFL_2017_Blitz_v2.png&quot;,&quot;スターウォーズ最後のジェダイ&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;vedovanera&quot;:&quot;blackwidow_IW_2018\/blackwidow_IW_2018.png&quot;,&quot;tissuetuesday&quot;:&quot;This_Is_Us_Mid_2018\/This_Is_Us_Mid_2018.png&quot;,&quot;saferinternetday&quot;:&quot;SaferInternetDAy2018\/SaferInternetDAy2018.png&quot;,&quot;honorview10&quot;:&quot;Huawei_Honorglobal_Launch_Emoji_v2\/Huawei_Honorglobal_Launch_Emoji_v2.png&quot;,&quot;thevoiceuk&quot;:&quot;thevoiceuk_2018\/thevoiceuk_2018.png&quot;,&quot;manofthewoods&quot;:&quot;JustinTimberlake_MOTW\/JustinTimberlake_MOTW.png&quot;,&quot;gliultimijedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;espejopúblico&quot;:&quot;EspejoPublico_2017_2018\/EspejoPublico_2017_2018.png&quot;,&quot;arie&quot;:&quot;Bachelor_2018_v3\/Bachelor_2018_v3.png&quot;,&quot;timmusic&quot;:&quot;TIM_Sanremo_2018-v3\/TIM_Sanremo_2018-v3.png&quot;,&quot;국가대표&quot;:&quot;WinterOlympics_KoreanMinistry\/WinterOlympics_KoreanMinistry.png&quot;,&quot;phantom30&quot;:&quot;PhantomofTheOpera_2018\/PhantomofTheOpera_2018.png&quot;,&quot;ポーグ&quot;:&quot;The_Last_Jedi_Porg_emoji_v5\/The_Last_Jedi_Porg_emoji_v5.png&quot;,&quot;국가대표고마워&quot;:&quot;WinterOlympics_KoreanMinistry\/WinterOlympics_KoreanMinistry.png&quot;,&quot;lesderniersjedi&quot;:&quot;The_Last_Jedi_BB8_emoji_v3\/The_Last_Jedi_BB8_emoji_v3.png&quot;,&quot;feiticeiraescarlate&quot;:&quot;Scarlet_Witch\/Scarlet_Witch.png&quot;,&quot;droid&quot;:&quot;The_Last_Jedi_BB-9E_emoji_v4\/The_Last_Jedi_BB-9E_emoji_v4.png&quot;,&quot;thor&quot;:&quot;thor_IW_2018\/thor_IW_2018.png&quot;,&quot;wakanda&quot;:&quot;blackpanther_IW_2018\/blackpanther_IW_2018.png&quot;,&quot;alleyesnorth&quot;:&quot;NBA_2017_18_MIN\/NBA_2017_18_MIN.png&quot;,&quot;rocketmortgage&quot;:&quot;QuickenLoans\/QuickenLoans.png&quot;,&quot;doctorstrange&quot;:&quot;drstrange_IW_2018_v2\/drstrange_IW_2018_v2.png&quot;},&quot;initialState&quot;:{&quot;title&quot;:&quot;Login on Twitter&quot;,&quot;section&quot;:null,&quot;module&quot;:&quot;app\/pages\/login&quot;,&quot;cache_ttl&quot;:300,&quot;body_class_names&quot;:&quot;three-col logged-out&quot;,&quot;doc_class_names&quot;:&quot;route-login login-responsive&quot;,&quot;route_name&quot;:&quot;login&quot;,&quot;page_container_class_names&quot;:&quot;AppContent wrapper wrapper-login&quot;,&quot;ttft_navigation&quot;:false}}">

  

    <input type="hidden" class="swift-boot-module" value="app/pages/login">
  <input type="hidden" id="swift-module-path" value="https://abs.twimg.com/k/swift/en">

  
    <script src="https://abs.twimg.com/k/en/init.en.43a39fee7e0348fab71a.js" async></script>

  </body>
</html>
