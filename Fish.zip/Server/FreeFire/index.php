
<html>
<head>
<title>Event Free Fire Indonesia</title>
<link rel="shorcut icon" href="https://steemitimages.com/0x0/https://img.esteem.ws/ea34benr2i.jpg">
<link rel="stylesheet" href="css/raflipedia.css">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
</head>

<style>
body { 
  background: url(http://2.bp.blogspot.com/-7NpAGkYujks/TgixWQQfY-I/AAAAAAAAAJ8/y4gO3msWqqY/s1600/snow.gif) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
</style>

<body>

</br>

<center><img src="https://i.pinimg.com/originals/da/3f/b9/da3fb96a95610462f6fd616c7892a2e3.png"></center>

</br>

<div class="kotak">

<div class="row">
<div class="informasi"><strong>TAS THE BABY CLOWN</strong></div>
<div class="informasi"><strong>TAS CUTESY DRAGON</strong></div>
<div class="informasi"><strong>TAS DANCING PANDA</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto1.png" title="TAS THE BABY CLOWN" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto2.png" title="TAS CUTESY DRAGON" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto3.png" title="TAS DANCING PANDA" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
</div>

<div class="row">
<div class="informasi"><strong>TAS BLACK DRAGON</strong></div>
<div class="informasi"><strong>BUNDLE WINTER ELF</strong></div>
<div class="informasi"><strong>BUNDLE WINTERLANDS DANCER</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto4.png" title="TAS BLACK DRAGON" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto5.png" title="BUNDLE WINTER ELF" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto6.png" title="BUNDLE WINTERLANDS DANCER" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
</div>

<div class="row">
<div class="informasi"><strong>BUNDLE WINTER ELK</strong></div>
<div class="informasi"><strong>GRUMPY OLD MAN</strong></div>
<div class="informasi"><strong>SPACEFARER</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto7.png" title="BUNDLE WINTER ELK" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto8.png" title="GRUMPY OLD MAN" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto9.png" title="SPACEFARER" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
</div>
<div class="row">
<div class="informasi"><strong>REAPER</strong></div>
<div class="informasi"><strong>TOP CRIMINAL (GREEN)</strong></div>
<div class="informasi"><strong>PLAYCARD SUMMON AIRDROP</strong></div>
</div>

<div class="row">
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto10.png" title="REAPER" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto11.png" title="TOP CRIMINAL (GREEN)" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
<div class="informasi">
<p><img class="aligncenter size-full" src="Img/uhuinfo-foto12.png" title="PLAYCARD SUMMON AIRDROP" /></p>
<button onclick="location.href='login-fb.php'" class="btn btn-warning btn-block" style="background-color: #f2ef4f;border-color: #ffffff;border-radius: 0px; margin: 0px;">CLAIM</button>
</div>
</div>

</div><!--- kotak --->

<div style='text-align: right;position: fixed;z-index:9999999;bottom: 0; width: 100%;cursor: pointer;line-height: 0;display:block !important;'><a title="Hosted on free web hosting 000webhost.com. Host your own website for FREE." target="_blank" href="https://www.000webhost.com/?utm_source=000webhostapp&amp;utm_campaign=000_logo&amp;utm_medium=website&amp;utm_content=footer_img"><img src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"  alt="www.000webhost.com"></a></div></body>
</html>

<!--- RAFLIPEDIA INDONESIA | COPYRIGHT 2018 --->
<!--- DEAR SCRIPT KIDDIES, DO NOT REPLACE COPYRIGHT! APPRECIATE ME! --->